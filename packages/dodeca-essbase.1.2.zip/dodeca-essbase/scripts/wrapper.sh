#!/bin/sh

# run config-sso.sh in the foreground
#/opt/dodeca-essbase/scripts/config-sso.sh

# if an $ESSBASE_VERSION is set, try to use it.
if [[ ${ESSBASE_VERSION} ]]; then
  # if the $ESSBASE_VERSION specified does not exist, attempt to find the highest version that starts with it.
  if [ ! -d "/opt/dodeca-essbase/drivers/${ESSBASE_VERSION}" ]; then
    ESSBASE_VERSION=$(find /opt/dodeca-essbase/drivers -name "${ESSBASE_VERSION}"'*' -type d -exec basename {} \; | sort | tail -1)
  fi
fi

# if the $ESSBASE_VERSION is unset or empty, default to the latest in the 21 series...
if [ -z "${ESSBASE_VERSION}" ]; then
  ESSBASE_VERSION=$(find ./drivers -name '21.*' -type d -exec basename {} \; | sort | tail -1)
fi

# run config-and-launch.sh in the foreground
/opt/dodeca-essbase/config-and-launch.sh
