#!/bin/sh

# if a DEPLOYMENT_URL is not set, we don't take the hit from manifestwriter generating the client deployments. 
if [[ -z "${DEPLOYMENT_URL}" ]]; then
  sleep 25
else
  sleep 90
fi

# run the mounted dshell script
(cd /opt/dodeca/tools && java -jar dshell.jar @../scripts/config-sso.dshell)

# retain the exit code
code=$?

# if necessary, report failure and exit
if [[ $code -ne 0 ]]; then
  echo -e "\nFailed to generate encryption keys and/or set tenant options.\n"
  exit $code
fi

echo -e "\nSucessfully generated encryption keys and set tenant options."
echo -e "Importing the encryption keys into the mounted keystore:"

# delete any existing encryption key certs from the mounted java keystore.
keytool -delete -alias starter_kit.localhost -keystore /opt/dodeca/localhost.jks -storepass changeit >/dev/null 2>&1
keytool -delete -alias sample.localhost      -keystore /opt/dodeca/localhost.jks -storepass changeit >/dev/null 2>&1
keytool -delete -alias demoapp.localhost     -keystore /opt/dodeca/localhost.jks -storepass changeit >/dev/null 2>&1

# import the encryption key certs into the mounted java keystore.
keytool -import -noprompt -trustcacerts -alias starter_kit.localhost -file /opt/dodeca/certs/starter_kit.localhost.cer -keystore /opt/dodeca/localhost.jks -storepass changeit
keytool -import -noprompt -trustcacerts -alias sample.localhost      -file /opt/dodeca/certs/sample.localhost.cer      -keystore /opt/dodeca/localhost.jks -storepass changeit
keytool -import -noprompt -trustcacerts -alias demoapp.localhost     -file /opt/dodeca/certs/demoapp.localhost.cer     -keystore /opt/dodeca/localhost.jks -storepass changeit

exit $?
