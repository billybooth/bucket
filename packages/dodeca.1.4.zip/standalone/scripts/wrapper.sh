#!/bin/sh

# run the h2 console in the background
java -Dh2.browser=/bin/true -jar /opt/dodeca/lib/h2-*.jar &

# run the mounted license import script in the background
#(cd /opt/dodeca/tools && sleep 15 && java -jar dshell.jar @../scripts/import-license.dshell) &> /dev/null &

# run the mounted metadata import script in the background
#(cd /opt/dodeca/tools && sleep 25 && java -jar dshell.jar @../scripts/import-tenants.dshell) &

# run config-and-launch.sh in the foreground
/opt/dodeca/config-and-launch.sh
