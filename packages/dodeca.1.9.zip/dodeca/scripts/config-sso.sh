#!/bin/sh

# run the mounted dshell script
(cd /opt/dodeca/tools && java -jar dshell.jar @../scripts/config-sso.dshell)

# retain the exit code
code=$?

# if necessary, report failure and exit
if [[ $code -ne 0 ]]; then
  echo -e "\nFailed to generate encryption keys and/or set tenant options.\n"
  exit $code
fi

echo -e "\nSucessfully generated encryption keys and set tenant options."

exit $?
