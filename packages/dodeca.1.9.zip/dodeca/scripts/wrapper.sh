#!/bin/sh

# run the h2 console in the background
java -Dh2.browser=/bin/true -jar /opt/dodeca/drivers/h2-*.jar &

# if there is no license metadata to auto-import BUT there is a mounted license, import the license with dshell
if [ ! -f /opt/dodeca/auto_import/___DODECA_SERVER_LICENSE___/___DODECA_SERVER_LICENSE___.zip ] && [ -f /opt/dodeca/license/dodeca.license ]; then
  (cd /opt/dodeca/tools && sleep 60 && java -jar dshell.jar @../scripts/import-license.dshell) &> /dev/null &
fi

# if there are no sso certificates exported, set the tenant config and export them with dshell
#if [ ! -f /opt/dodeca/certs/sample.localhost.cer ] || [ ! -f /opt/dodeca/certs/starter_kit.localhost.cer ] || [ ! -f /opt/dodeca/certs/demoapp.localhost.cer ]; then
  #(cd /opt/dodeca/tools && sleep 90 && java -jar dshell.jar @../scripts/config-sso.dshell) &> /dev/null &
#fi

# run config-and-launch.sh in the foreground
/opt/dodeca/config-and-launch.sh
