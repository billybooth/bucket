#!/usr/bin/env bash

# Runs the given command with the environment the buildpack launcher gives the server, without running the launcher.
#
# /cnb/lifecycle/launcher does two things before it runs a command: it applies the environment each buildpack layer
# declares for launch (the repository connection, the driver folder, JAVA_HOME, and so on), and it runs every exec.d
# helper of the image. One of those helpers, the certificate loader, rewrites the JVM truststore in place, so a second
# launch while the server is starting or running can read the truststore half-written and fail, or leave the server
# reading one that is. The launch environment is all the H2 console and Dodeca Shell need, so this script applies only
# that: a layer's NAME.default sets NAME when it is not already set and NAME.override always sets it, as the launcher
# does. The appended and prepended JAVA_TOOL_OPTIONS size the server's heap and are left out on purpose. The image's
# java is put on the PATH. In an image without buildpack layers the command runs unchanged.

for file in /layers/*/*/env.launch/*.default /layers/*/*/env.launch/*.override; do
  [ -f "${file}" ] || continue
  name="$(basename "${file}")"
  kind="${name##*.}"
  name="${name%.*}"
  if [ "${kind}" = "override" ] || [ -z "${!name+set}" ]; then
    export "${name}=$(cat "${file}")"
  fi
done

if [ -n "${JAVA_HOME}" ] && [ -x "${JAVA_HOME}/bin/java" ]; then
  export PATH="${JAVA_HOME}/bin:${PATH}"
fi

exec "$@"
