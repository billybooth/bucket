#!/usr/bin/env bash

# Boots the server-only (buildpack) image the way wrapper.sh boots the classic one: starts the H2 console on 8082 from
# the H2 driver the server ships, and then hands over to the image's own web process, so the server runs exactly as
# it would without this script. A mounted license file needs no import here: the launcher hands it to the server as
# its encoded startup license, which the server saves once its repository is ready.
#
# The container starts this script in place of /cnb/process/web, which means outside the buildpack launcher. The
# console runs outside the launcher too: buildpack-env.sh gives it the server's launch environment (the repository
# connection, java on the PATH) and calls this script again with the job's name. It must not run through
# /cnb/lifecycle/launcher, because every launch runs the image's exec.d helpers, and the certificate loader among them
# rewrites the JVM truststore in place, so a second launch at the same time as the server's reads it half-written and
# fails to start.

case "$1" in

  console)
    # the H2 console, with the repository saved as its first connection (H2 reads ~/.h2.server.properties).
    h2="$(ls /workspace/BOOT-INF/lib/h2-*.jar 2> /dev/null | sort | tail -n 1)"
    if [ -z "${h2}" ]; then
      echo "The image has no H2 driver, so the H2 console is not started."
      exit 0
    fi
    properties="${HOME:-/home/cnb}/.h2.server.properties"
    if [ ! -f "${properties}" ]; then
      url="${HIBERNATE_CONNECTION_URL:-jdbc:h2:/home/cnb/data/dodeca;AUTO_SERVER=TRUE;NON_KEYWORDS=VALUE}"
      escaped="$(printf '%s' "${url}" | sed 's/[:=]/\\&/g')"
      printf '0=Dodeca Repository|org.h2.Driver|%s|%s\nwebAllowOthers=true\nwebPort=8082\nwebSSL=false\n' \
        "${escaped}" "${HIBERNATE_CONNECTION_USERNAME:-sa}" > "${properties}"
    fi
    # JAVA_TOOL_OPTIONS given to the container are meant for the server process, not for the console.
    unset JAVA_TOOL_OPTIONS
    echo "Starting the H2 console on port 8082 with ${h2}..."
    exec java -cp "${h2}" org.h2.tools.Server -web -webAllowOthers -webPort 8082 > /dev/null 2>&1
    ;;

  *)
    /opt/dodeca/scripts/buildpack-env.sh /opt/dodeca/scripts/wrapper-server.sh console &

    echo "Starting Dodeca Server..."
    exec /cnb/process/web
    ;;

esac
