#!/usr/bin/env bash

# Boots the server-only (buildpack) image the way wrapper.sh boots the classic one: starts the H2 console on 8082 from
# the H2 driver the server ships, and then hands over to the image's own web process, so the server runs exactly as
# it would without this script. A mounted license file needs no import here: the launcher hands it to the server as
# its encoded startup license, which the server saves once its repository is ready.
#
# The container starts this script in place of /cnb/process/web, which means outside the buildpack launcher. The
# console runs outside the launcher too: buildpack-env.sh gives it the server's launch environment (the repository
# connection, java on the PATH) and calls this script again with the job's name. It must not run through
# /cnb/lifecycle/launcher, because every launch runs the image's exec.d helpers, and the certificate loader among them
# rewrites the JVM truststore in place, so a second launch at the same time as the server's reads it half-written and
# fails to start.
#
# The administrator job runs the same way. Servers before 8.11 sign in to their console with the administrator in
# DODECA_ADMIN_USERNAME and DODECA_ADMIN_PASSWORD; from 8.11 on those are no longer read, and administrators are
# principals in the repository. So once the server is ready, the job creates that same login as an administrator
# principal with Dodeca Shell, and the launcher's credentials sign in to every server; on 8.10 the principal is a
# second way in beside the configured administrator. The job waits while the server is not listening or answers that
# it is not ready yet (503), and creates the principal once the readiness page answers 200. Any other answer means the
# server has no readiness page, and the job ends without creating anything.

# prints the HTTP status of the server's readiness page, or nothing while the server is not listening yet.
readiness() {
  (
    exec 3<> /dev/tcp/127.0.0.1/8000
    printf 'GET /dodeca/health/ready HTTP/1.0\r\nHost: localhost\r\n\r\n' >&3
    head -n 1 <&3 | cut -d ' ' -f 2
  ) 2> /dev/null
}

case "$1" in

  administrator)
    if [ -z "${DODECA_ADMIN_USERNAME}" ] || [ -z "${DODECA_ADMIN_PASSWORD}" ]; then
      exit 0
    fi
    # wait up to thirty minutes, as long as a large auto import can take.
    status=""
    for attempt in $(seq 1 900); do
      status="$(readiness)"
      if [ -n "${status}" ] && [ "${status}" != "503" ]; then
        break
      fi
      sleep 2
    done
    if [ -z "${status}" ] || [ "${status}" = "503" ]; then
      exit 0
    fi
    # "dodeca wait" holds until this job writes a line that starts "Sign in to the administration console" or holds
    # "could not be created", so every answer from the server ends with one of them.
    if [ "${status}" != "200" ]; then
      echo "Sign in to the administration console as ${DODECA_ADMIN_USERNAME} with the password ${DODECA_ADMIN_PASSWORD}."
      exit 0
    fi
    # the shell connects to the server's own repository: the image gives no HIBERNATE_CONNECTION_URL, only the data
    # directory its H2 repository is in. Older shells find a connection file by its name in the folder dshell.sh runs
    # in, so the file goes there under a name of its own.
    connection="/opt/dodeca/tools/administrator.dodeca.properties"
    script="$(mktemp)"
    log="$(mktemp)"
    url="${HIBERNATE_CONNECTION_URL:-jdbc:h2:${DODECA_DATA_DIRECTORY:-/home/cnb/data}/dodeca;AUTO_SERVER=TRUE}"
    driver_class="${HIBERNATE_CONNECTION_DRIVER_CLASS}"
    if [ -z "${driver_class}" ] && [[ "${url}" == jdbc:h2:* ]]; then
      driver_class="org.h2.Driver"
    fi
    {
      [ -n "${driver_class}" ] && echo "hibernate.connection.driver_class=${driver_class}"
      echo "hibernate.connection.url=${url}"
      echo "hibernate.connection.username=${HIBERNATE_CONNECTION_USERNAME:-sa}"
      echo "hibernate.connection.password=${HIBERNATE_CONNECTION_PASSWORD}"
    } > "${connection}"
    printf 'connect %s\n' "$(basename "${connection}")" > "${script}"
    printf 'principal-native-admin-create --username "%s" --name "Server Administrator" --secret-source %s\n' \
      "${DODECA_ADMIN_USERNAME}" "env:DODECA_ADMIN_PASSWORD" >> "${script}"
    if /opt/dodeca/scripts/dshell.sh @"${script}" > "${log}" 2>&1; then
      echo "Sign in to the administration console as ${DODECA_ADMIN_USERNAME} with the password ${DODECA_ADMIN_PASSWORD}."
    else
      reason="$(grep 'Command failed' "${log}" | tail -n 1 | sed 's/.*Command failed: //')"
      echo "The administrator ${DODECA_ADMIN_USERNAME} could not be created: ${reason:-see dodeca follow}."
    fi
    rm -f "${connection}" "${script}" "${log}"
    ;;

  console)
    # the H2 console, with the repository saved as its first connection (H2 reads ~/.h2.server.properties).
    h2="$(ls /workspace/BOOT-INF/lib/h2-*.jar 2> /dev/null | sort | tail -n 1)"
    if [ -z "${h2}" ]; then
      echo "The image has no H2 driver, so the H2 console is not started."
      exit 0
    fi
    properties="${HOME:-/home/cnb}/.h2.server.properties"
    if [ ! -f "${properties}" ]; then
      url="${HIBERNATE_CONNECTION_URL:-jdbc:h2:/home/cnb/data/dodeca;AUTO_SERVER=TRUE;NON_KEYWORDS=VALUE}"
      escaped="$(printf '%s' "${url}" | sed 's/[:=]/\\&/g')"
      printf '0=Dodeca Repository|org.h2.Driver|%s|%s\nwebAllowOthers=true\nwebPort=8082\nwebSSL=false\n' \
        "${escaped}" "${HIBERNATE_CONNECTION_USERNAME:-sa}" > "${properties}"
    fi
    # JAVA_TOOL_OPTIONS given to the container are meant for the server process, not for the console.
    unset JAVA_TOOL_OPTIONS
    echo "Starting the H2 console on port 8082 with ${h2}..."
    exec java -cp "${h2}" org.h2.tools.Server -web -webAllowOthers -webPort 8082 > /dev/null 2>&1
    ;;

  *)
    /opt/dodeca/scripts/buildpack-env.sh /opt/dodeca/scripts/wrapper-server.sh console &
    /opt/dodeca/scripts/buildpack-env.sh /opt/dodeca/scripts/wrapper-server.sh administrator &

    echo "Starting Dodeca Server..."
    exec /cnb/process/web
    ;;

esac
