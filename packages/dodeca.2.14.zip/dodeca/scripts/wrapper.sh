#!/usr/bin/env bash

set -eo pipefail

# attempt to locate the most appropriate h2 driver for this container.

# if the h2 driver is present in /lib, use it.
if test -n "$(find /opt/dodeca/lib/ -maxdepth 1 -name 'h2*.jar' -print -quit)"; then
  best_h2_driver="/opt/dodeca/lib/$(ls -d /opt/dodeca/lib/h2*.jar | xargs -n 1 basename | sort -n | tail -n 1)"
# else if the h2 driver is present in /drivers, use it.
elif test -n "$(find /opt/dodeca/drivers/ -maxdepth 1 -name 'h2*.jar' -print -quit)"; then
  best_h2_driver="/opt/dodeca/drivers/$(ls -d /opt/dodeca/drivers/h2*.jar | xargs -n 1 basename | sort -n | tail -n 1)"
fi

# if an h2 driver was found, run the h2 console in the background using it.
if [ -f "$best_h2_driver" ]; then
  # if the best driver is located in /lib, clobber any other h2 drivers and copy it over for dshell.
  if [ "$(basename $(dirname "$best_h2_driver"))" = "lib" ]; then
    rm -f /opt/dodeca/drivers/h2*.jar >/dev/null 2>&1
    cp -f "$best_h2_driver" /opt/dodeca/drivers/ >/dev/null 2>&1
  fi
  
  printf "\nStarting H2 console with $best_h2_driver...\n\n"
  
  # commented command only works with newer driver.
  #java -cp h2*.jar org.h2.tools.GUIConsole -Dh2.browser=/bin/true -jar "$best_h2_driver" > /dev/null 2>&1 &
  java -Dh2.browser=/bin/true -jar "$best_h2_driver" > /dev/null 2>&1 &
fi

# if there is a mounted license, import it with dshell. The launcher also passes it as the encoded startup license,
# which images before 8.7.0 ignore, so this import keeps those licensed and is a harmless repeat on newer ones.
if [ -f /opt/dodeca/license/dodeca.license ]; then
  (cd /opt/dodeca/tools && sleep 60 && java -jar dshell.jar @../scripts/import-license.dshell) &> /dev/null &
fi

# if there are no sso certificates exported, set the tenant config and export them with dshell.
#if [ ! -f /opt/dodeca/certs/sample.localhost.cer ] || [ ! -f /opt/dodeca/certs/starter_kit.localhost.cer ] || [ ! -f /opt/dodeca/certs/demoapp.localhost.cer ]; then
  #(cd /opt/dodeca/tools && sleep 90 && java -jar dshell.jar @../scripts/config-sso.dshell) &> /dev/null &
#fi

if [ -f /opt/dodeca/smartclient/AppliedOLAP.Dodeca.SmartClient.application ]; then
  export DODECA_CLIENT_DEPLOYMENT_TYPE="repository"
  printf "Importing standard clients in the background.\n\n"
  touch /opt/dodeca/logs/dodeca.log > /dev/null 2>&1
  (cd /opt/dodeca/smartclient && zip -0 -r ../smartclient.zip . && rm -rf ./* && mv ../smartclient.zip ./ && cd /opt/dodeca/exceladdin && zip -0 -r ../exceladdin.zip ./ && rm -rf ./* && mv ../exceladdin.zip ./) &> /dev/null &
  (while ! grep -q "Initializing Dodeca license manager" "/opt/dodeca/logs/dodeca.log"; do sleep 1; done; cd /opt/dodeca/tools && java -jar dshell.jar @../scripts/import-clients.dshell) &> /dev/null &
elif [[ -z "${DEPLOYMENT_URL}" ]]; then
  printf "Skipping manifest creation as DEPLOYMENT_URL was not specified.\n\n"
elif [ -f /opt/dodeca/tools/manifestwriter ]; then
  # run config-and-launch.sh in the foreground.
  # Expects a DEPLOYMENT_URL such as http://localhost:8000/dodeca
  echo Signing manifest...
  tools/manifestwriter --inputwarcontentpath=. --deploymenturl=${DEPLOYMENT_URL} --packagewar=false
fi

# capture java version, i.e., 17.0.15
java_version=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')

if [ -n "${DODECA_DATA_SOURCE_FACTORY_MAXIMUM_POOL_SIZE}" ] || [ -n "${DODECA_DATA_SOURCE_FACTORY_MINIMUM_IDLE}" ]; then
    server_jar=$(ls /opt/dodeca/lib/dodeca-server-*.jar 2>/dev/null | head -1)
    if [ -n "$server_jar" ]; then
        tmpdir=$(mktemp -d)
        unzip -q "$server_jar" dodeca.properties -d "$tmpdir"
        if [ -n "${DODECA_DATA_SOURCE_FACTORY_MAXIMUM_POOL_SIZE}" ]; then
            sed -i "s|^dodeca.data-source-factory.maximum-pool-size=.*|dodeca.data-source-factory.maximum-pool-size=${DODECA_DATA_SOURCE_FACTORY_MAXIMUM_POOL_SIZE}|" "$tmpdir/dodeca.properties"
        fi
        # When pool size is constrained, minimum-idle must match or HikariCP discards the
        # init connection (min-idle=0 means "don't keep idle connections"), forcing a new
        # CreateTokenWithIAM call on every getConnection() — which fails for EXT_JWT because
        # jti is single-use. Default minimum-idle to pool size when not explicitly set.
        _dodeca_min_idle="${DODECA_DATA_SOURCE_FACTORY_MINIMUM_IDLE:-${DODECA_DATA_SOURCE_FACTORY_MAXIMUM_POOL_SIZE}}"
        if [ -n "${_dodeca_min_idle}" ]; then
            sed -i "s|^dodeca.data-source-factory.minimum-idle=.*|dodeca.data-source-factory.minimum-idle=${_dodeca_min_idle}|" "$tmpdir/dodeca.properties"
        fi
        (cd "$tmpdir" && zip -u "$server_jar" dodeca.properties)
        rm -rf "$tmpdir"
    fi
fi

export ROOT_LOG_LEVEL="${ROOT_LOG_LEVEL:-DEBUG}"

echo Starting Dodeca Server...

if [[ "$java_version" > "17" ]]; then
  java --class-path lib/wrapper.jar:drivers/*:lib/* --module-path drivers/*:lib/* --add-opens java.base/java.nio=ALL-UNNAMED ${DODECA_JAVA_OPTS} com.appliedolap.dodeca.server.Application | tee /opt/dodeca/logs/dodeca.log
else
  java -cp lib/wrapper.jar:drivers/*:lib/* ${DODECA_JAVA_OPTS} com.appliedolap.dodeca.server.Application | tee /opt/dodeca/logs/dodeca.log
fi
