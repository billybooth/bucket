#!/bin/sh

# if there is no mounted license to import, exit.
if [ ! -f /opt/dodeca/license/dodeca.license ]; then
  exit 1
fi

# run the mounted dshell script
(cd /opt/dodeca/tools && java -jar dshell.jar @../scripts/import-license.dshell)

# retain the exit code
code=$?

# if necessary, report failure and exit
if [[ $code -ne 0 ]]; then
  echo -e "\nFailed to import the license file.\n"
  exit $code
fi

echo -e "\nSucessfully imported the license file."

exit $?
