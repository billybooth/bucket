@echo off
setlocal EnableDelayedExpansion

:: Two image layouts are supported, and each is detected from the image (or running container) rather than its tag:
::
::   standalone - the classic /opt/dodeca image (8.9.x and earlier): the full standalone package with Dodeca Shell,
::                the H2 console, and the wrapper.sh entrypoint that imports the license and clients.
::   server     - the server-only buildpack image (8.10.0 and later): just the server, launched by /cnb/process/web
::                with the repository under /home/cnb and drivers under /workspace/drivers. Dodeca Shell is not in
::                the image, so it is mounted from "%USERPROFILE%\standalone\dodeca\tools" ("dodeca tools <version>").

:: if this is the export command, run an interactive export-tenants script and exit.
if "%1" == "export" (
  call :detect_container || goto :eof
  !EXEC! /opt/dodeca/scripts/export-tenants.sh
  goto :eof
)

:: if this is the shell command, run an interactive dshell script and then exit.
if "%1" == "shell" (
  call :detect_container || goto :eof
  !EXEC! /opt/dodeca/scripts/dshell.sh
  goto :eof
)

:: if this is the license command, import the mounted license file with dshell and then exit.
if "%1" == "license" (
  call :detect_container || goto :eof
  !EXEC! /opt/dodeca/scripts/import-license.sh
  goto :eof
)

:: if this is the bash command, create an interactive bash shell and then exit.
if "%1" == "bash" (
  call :detect_container || goto :eof
  !EXEC! bash
  goto :eof
)

:: if this is the tools command, download Dodeca Shell for the server-only image and then exit.
if "%1" == "tools" (
  goto :tools
)

:: if this is the start command, set the docker flags for a detached container.
if "%1" == "start" (
  set "FLAGS=-d"
  goto :continue
)

:: if this is the run command, set the docker flags for an interactive container.
if "%1" == "run" (
  set "FLAGS=-it"
  goto :continue
)

if "%1" == "stop" (
  echo Stopping dodeca container...

  docker stop dodeca

  echo Done.
  goto :eof
)

if "%1"=="status" (
  docker ps -a --no-trunc --filter "name=^/dodeca$" --format "table {{.Image}}\t{{.Names}}\t{{.Status}}"
  goto :eof
)

if "%1"=="follow" (
  docker logs --follow dodeca
  goto :eof
)

echo No recognized command given for dodeca.
echo Try one of "run", "start", "stop", "export", "shell", "license", "bash", "tools", "status", "follow".
echo.
echo For example: "dodeca run 8.4", "dodeca shell", or "dodeca tools 8.10.0"
goto :eof

:continue

:: Use the script directory as the working directory.
pushd "%~dp0"

:: If the standalone and dodeca directories does not exist, create them (and copy or update the source folder).
if not exist "%USERPROFILE%\standalone\" mkdir "%USERPROFILE%\standalone\"

if not exist "%USERPROFILE%\standalone\dodeca" (
  robocopy .\dodeca "%USERPROFILE%\standalone\dodeca" /e /nfl /ndl /njh /njs /np
) else (
  robocopy .\dodeca "%USERPROFILE%\standalone\dodeca" /e /nfl /ndl /njh /njs /np /is /im /it /s >nul 2>&1
)

:: set an encoded license variable.
::set "DODECA_ENCODED_STARTUP_LICENSE="

:: set the BRANCH variable (whether or not it was passed).
if not [%2]==[] (
  set BRANCH=%2
) else (
  set BRANCH=latest
)

:: set the ENVIRONMENT variable (if one was passed).
if not [%3]==[] (
  set THIRD_ARG=%3
  :: if the third arg contains an equal sign, process it as the ENVIRONMENT variable
  if not "!THIRD_ARG!"=="!THIRD_ARG:==!" (
    set ENVIRONMENT=%~3
    set ENVIRONMENT=-e "!ENVIRONMENT:;=" -e "!"
  )
)

:: if a dodeca.license file does not exist, a license is not available for auto-import, and
:: a DODECA_ENCODED_STARTUP_LICENSE is not passed for the environment, inform the user.
if not exist "%USERPROFILE%\standalone\dodeca\license\dodeca.license" (
  if not exist "%USERPROFILE%\standalone\dodeca\auto_import\___DODECA_SERVER_LICENSE___\___DODECA_SERVER_LICENSE___.zip" (
    echo.%ENVIRONMENT% | findstr /C:"DODECA_ENCODED_STARTUP_LICENSE" >nul 2>&1 || (
      echo Add a dodeca.license file to the "%USERPROFILE%\standalone\dodeca\license\" folder before continuing.
      pause
    )
  )
)

:: if the DODECA_DEPLOY_CLIENTS variable is set to false, do not set a DODECA_DEPLOYMENT_URL.
if "%DODECA_DEPLOY_CLIENTS%" neq "false" (
  :: otherwise, if a DODECA_DEPLOYMENT_URL is not already already defined, set one.
  if not defined DODECA_DEPLOYMENT_URL (
    :: set the DODECA_DEPLOYMENT_HOST variable based on the machine hostname.
    for /f "usebackq" %%a in (`hostname`) do set "DODECA_DEPLOYMENT_HOST=%%a"
    :: use the DODECA_DEPLOYMENT_HOST or localhost to set the DODECA_DEPLOYMENT_URL.
    if "!DODECA_DEPLOYMENT_HOST!" neq "" (
      set "DODECA_DEPLOYMENT_URL=http://!DODECA_DEPLOYMENT_HOST!:8000/dodeca"
    ) else (
      set "DODECA_DEPLOYMENT_URL=http://localhost:8000/dodeca"
    )
  )
)

:: create the standalone network if it doesn't exist...
docker network create --driver bridge standalone > nul 2>&1

:: set the window title if we are running an interactive container.
if "%1"=="run" title Dodeca Server (%BRANCH%)

::"ghcr.io/appliedolap/dodeca:%BRANCH%"
::"appliedolap/dodeca:%BRANCH%"

:: check whether a tag exists for the specified tag, and if not, append "-latest"
set "IMAGE=ghcr.io/appliedolap/dodeca:%BRANCH%"
docker manifest inspect "ghcr.io/appliedolap/dodeca:%BRANCH%" >nul 2>&1 || (
  set "IMAGE=ghcr.io/appliedolap/dodeca:%BRANCH%.0"
  docker manifest inspect "ghcr.io/appliedolap/dodeca:%BRANCH%.0" >nul 2>&1 || (
    echo ghcr.io/appliedolap/dodeca:%BRANCH% unavailable.
    set "IMAGE=appliedolap/dodeca:standalone-%BRANCH%"
    docker manifest inspect "appliedolap/dodeca:standalone-%BRANCH%" >nul 2>&1 || (
      echo appliedolap/dodeca:standalone-%BRANCH% unavailable.
      set "IMAGE=appliedolap/dodeca:standalone-%BRANCH%-latest"
      docker manifest inspect "appliedolap/dodeca:standalone-%BRANCH%-latest" >nul 2>&1 || (
        echo appliedolap/dodeca:standalone-%BRANCH%-latest unavailable.
        set "IMAGE=ghcr.io/appliedolap/dodeca:latest"
      )
    )
  )
)

:: pull the image up front (rather than with --pull always) so that its layout can be inspected before it runs.
docker pull "%IMAGE%" || (
  echo Unable to pull %IMAGE%.
  goto :eof
)

call :detect_layout image "%IMAGE%"

:: the host folders and the docker options shared by both layouts.
set "HOST_DIR=%USERPROFILE%\standalone\dodeca"
set "RUN=docker run --rm --name dodeca %FLAGS% -p 8000:8000 --network=standalone --dns 8.8.8.8 --dns 8.8.4.4 --add-host host.docker.internal:host-gateway"
set "ENV=-e DODECA_ADMIN_ENABLED=true -e DODECA_ADMIN_USERNAME=admin -e DODECA_ADMIN_PASSWORD=password1 -e DODECA_ADMIN_ROLES=USER,ADMIN -e DODECA_AUTO_IMPORT_ON_STARTUP=true -e DODECA_CHECKSUM_FUNCTION=SHA-256 -e DODECA_COMMENTS_AUDIT_LOGGING=true -e DODECA_LANDING_PAGE_LIST_APPS=true -e DODECA_LOG_LEVEL=TRACE -e DODECA_RECOMPUTE_CHECKSUMS_ON_STARTUP=true -e DODECA_UPDATE_SCHEMA_ON_STARTUP=true -e DODECA_XML_LOGGING_LOG_TO_CONSOLE=true -e DSHELL_STARTUP_CONNECTION=local.dodeca.properties"

if "%LAYOUT%"=="server" goto :run_server

:: the standalone layout mounts the package folders into /opt/dodeca and boots through wrapper.sh, which starts the
:: H2 console on 8082, imports a mounted license and the clients with dshell, and signs the ClickOnce manifests.
set "MOUNTS=-v "%HOST_DIR%\auto_import:/opt/dodeca/auto_import" -v "%HOST_DIR%\config\wrapper.conf:/opt/dodeca/conf/wrapper.conf" -v "%HOST_DIR%\drivers:/opt/dodeca/drivers" -v "%HOST_DIR%\license:/opt/dodeca/license" -v "%HOST_DIR%\root:/root" -v "%HOST_DIR%\scripts:/opt/dodeca/scripts""

:: run the container with a deployment url, if clients will be deployed,
:: echoing the command to the console.
if "%DODECA_DEPLOY_CLIENTS%" neq "false" (
  @echo on
  for %%. in (.) do %RUN% -p 8082:8082 --entrypoint /opt/dodeca/scripts/wrapper.sh -e "DEPLOYMENT_URL=%DODECA_DEPLOYMENT_URL%" %ENV% %ENVIRONMENT% %MOUNTS% "%IMAGE%"
  @echo off
) else (
  @echo on
  for %%. in (.) do %RUN% -p 8082:8082 --entrypoint /opt/dodeca/scripts/wrapper.sh %ENV% %ENVIRONMENT% %MOUNTS% "%IMAGE%"
  @echo off
)
goto :eof

:run_server

:: the server-only layout has no wrapper.sh, no H2 console, no client deployment, and no Dodeca Shell of its own.
:: The license is expected in auto_import (or DODECA_ENCODED_STARTUP_LICENSE); a license file is imported on demand.
if not exist "%HOST_DIR%\auto_import\___DODECA_SERVER_LICENSE___\___DODECA_SERVER_LICENSE___.zip" (
  if exist "%HOST_DIR%\license\dodeca.license" (
    echo The server-only image does not import license\dodeca.license on startup: run "dodeca license" once the server is up.
  )
)
if not exist "%HOST_DIR%\tools\dshell.jar" (
  echo Dodeca Shell is not part of the server-only image: run "dodeca tools %BRANCH%" before using "dodeca shell", "dodeca export", or "dodeca license".
)

:: The server reads auto_import relative to its /workspace working directory, while the dshell scripts keep their
:: /opt/dodeca paths for both layouts, so the auto_import folder is mounted at both locations.
set "MOUNTS=-v "%HOST_DIR%\auto_import:/workspace/auto_import" -v "%HOST_DIR%\auto_import:/opt/dodeca/auto_import" -v "%HOST_DIR%\drivers:/workspace/drivers" -v "%HOST_DIR%\license:/opt/dodeca/license" -v "%HOST_DIR%\scripts:/opt/dodeca/scripts" -v "%HOST_DIR%\tools:/opt/dodeca/tools""

@echo on
for %%. in (.) do %RUN% %ENV% %ENVIRONMENT% %MOUNTS% "%IMAGE%"
@echo off
goto :eof

:tools

:: download the standalone distribution for the given version from its GitHub release and keep only Dodeca Shell.
if [%2]==[] (
  echo Specify the Dodeca version whose Dodeca Shell should be downloaded, for example "dodeca tools 8.10.0".
  goto :eof
)

set "TAG=v%~2"
set "TOOLS_DIR=%USERPROFILE%\standalone\dodeca\tools"
set "DOWNLOAD_DIR=%TEMP%\dodeca-tools-%~2"

if not exist "%TOOLS_DIR%\" mkdir "%TOOLS_DIR%\"
if not exist "%DOWNLOAD_DIR%\" mkdir "%DOWNLOAD_DIR%\"

echo Downloading dodeca-server-standalone.zip from the %TAG% release of appliedolap/Dodeca...
gh release download "%TAG%" --repo appliedolap/Dodeca --pattern dodeca-server-standalone.zip --dir "%DOWNLOAD_DIR%" --clobber || (
  echo Unable to download the %TAG% release; check "gh auth status" and the release tag.
  goto :eof
)

echo Extracting dshell.jar to "%TOOLS_DIR%"...
"%SystemRoot%\System32\tar.exe" -xf "%DOWNLOAD_DIR%\dodeca-server-standalone.zip" -C "%TOOLS_DIR%" --strip-components=1 tools/dshell.jar || (
  echo Unable to extract tools/dshell.jar from "%DOWNLOAD_DIR%\dodeca-server-standalone.zip".
  goto :eof
)

del /q "%DOWNLOAD_DIR%\dodeca-server-standalone.zip"
rmdir "%DOWNLOAD_DIR%"

echo Done.
goto :eof

:detect_container

:: the running container sets EXEC to the docker exec prefix its layout needs: the server-only image has to go
:: through the buildpack launcher, which supplies the server's environment and puts java on the PATH.
call :detect_layout container dodeca
if not defined LAYOUT (
  echo The dodeca container is not running.
  exit /b 1
)
if "%LAYOUT%"=="server" (
  set "EXEC=docker exec -it dodeca /cnb/lifecycle/launcher"
) else (
  set "EXEC=docker exec -it dodeca"
)
exit /b 0

:detect_layout

:: sets LAYOUT to "server" when the image or container (%1) named by %2 is launched by the buildpack process,
:: "standalone" for anything else, or leaves it undefined when there is nothing to inspect.
set "LAYOUT="
set "ENTRYPOINT="
for /f "usebackq delims=" %%e in (`docker %1 inspect %2 --format "{{.Config.Entrypoint}}" 2^>nul`) do set "ENTRYPOINT=%%e"
if not defined ENTRYPOINT exit /b 0
if "%ENTRYPOINT%"=="[/cnb/process/web]" (
  set "LAYOUT=server"
) else (
  set "LAYOUT=standalone"
)
exit /b 0
