#!/usr/bin/env bash

# capture the datetime
date=$(date '+%Y.%m.%d_%H.%M.%S')

# run the mounted dshell script
/opt/dodeca/scripts/dshell.sh @/opt/dodeca/scripts/export-tenants.dshell

# retain the exit code
result=$?

# if necessary, report failure and exit
if [ $result -ne 0 ]; then
  echo -e "\nFailed to export one or more tenants.\n"
  exit $result
fi

echo

# for each .zip file exported to the auto_import directory...
for i in /opt/dodeca/auto_import/*.zip; do
  # if the file doesn't exist, continue.
  [ -f "$i" ] || continue 
  
  # extract the filename, basename without extension, and directory.
  file=$(basename -- "$i")
  base=$(basename "$i" .zip)
  dir="${file%.*}"
  
  # if the destination file already exists...
  if [ -f "/opt/dodeca/auto_import/$dir/$file" ]; then
    if command -v unzip > /dev/null 2>&1; then
      # because we can't depend on proper inline subshell support, pipe the .zip content details to disk for comparison.
      unzip -v -l "/opt/dodeca/auto_import/$dir/$file" | awk '!/metadata\/(metadata-audit-log|view-usage).xml$/ { print $7, $8 }' > "/opt/dodeca/auto_import/$base.orig.txt"
      unzip -v -l "/opt/dodeca/auto_import/$file"      | awk '!/metadata\/(metadata-audit-log|view-usage).xml$/ { print $7, $8 }' > "/opt/dodeca/auto_import/$base.new.txt"
      
      # determine whether relevant contents of the .zip files differ.
      cmp -s "/opt/dodeca/auto_import/$base.orig.txt" "/opt/dodeca/auto_import/$base.new.txt"
      
      # retain the result of the comparison
      result=$?
      
      # clean up the on-disk .zip content details used for comparison.
      rm "/opt/dodeca/auto_import/$base.orig.txt"
      rm "/opt/dodeca/auto_import/$base.new.txt"
    else
      # the server-only image has no unzip, so the .zip files cannot be compared: keep the original regardless.
      echo "Metadata not compared : unzip is unavailable in this image."
      result=1
    fi
    
    # if the contents of the .zip files differ, backup the original .zip before replacing it.
    if [ $result -ne 0 ]; then
      echo "Metadata changed       : $file will be backed up."
      mv "/opt/dodeca/auto_import/$dir/$file" "/opt/dodeca/auto_import/$dir/$dir.$date.zip.bak" || { echo "Failed to backup existing $file." ; exit 1; }
    else
      echo "Metadata hasn't changed: $file"
    fi
  fi
  
  # move the exported file to the appropriate auto_import directory.
  mkdir -p "/opt/dodeca/auto_import/$dir/"
  mv "/opt/dodeca/auto_import/$file" "/opt/dodeca/auto_import/$dir/$file" || { echo "Failed to update $file with new metadata." ; exit 1; }
done

echo
echo "Sucessfully exported tenants."
