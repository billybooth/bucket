#!/usr/bin/env bash

# if there is no mounted license to import, exit.
if [ ! -f /opt/dodeca/license/dodeca.license ]; then
  echo "There is no license file to import at /opt/dodeca/license/dodeca.license."
  exit 1
fi

# run the mounted dshell script
/opt/dodeca/scripts/dshell.sh @/opt/dodeca/scripts/import-license.dshell

# retain the exit code
code=$?

# if necessary, report failure and exit
if [[ $code -ne 0 ]]; then
  echo -e "\nFailed to import the license file.\n"
  exit $code
fi

echo -e "\nSucessfully imported the license file."

exit $?
