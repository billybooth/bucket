# Moves the tenant exports that Dodeca Shell leaves in the auto_import folder into their tenant folders, backing up
# the previous export only when its contents changed.
#
# This runs on the host rather than in the container because the server-only (buildpack) image has no unzip. It also
# generates the tenant registration (metadata/tenants.xml) for exports that lack it: Dodeca Shell 8.10 and earlier do
# not export it, and a fresh 8.11 repository rolls back any tenant import that is not registered first (#4721).
param(
    [Parameter(Mandatory = $true)]
    [string]$AutoImport
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem

$tenantsEntry = 'metadata/tenants.xml'

# The audit logs, view usage, the manifest that counts them, and a generated tenant registration change with every
# export, so they are not compared.
$ignored = '^metadata/(metadata_audit_log|metadata_audit_log_items|view_usage_log|manifest|tenants)\.xml$'

# Every import stamps each artifact with who imported it and when, so a server restart that re-imports auto_import
# changes every artifact. Those stamps are not compared.
$importStamps = '<Imported(By|Date)(/>|>[^<]*</Imported\1>)'

# A metadata file with no items is the same as no file: newer versions of Dodeca Shell export object types (such as
# tenant configuration) that older versions leave out.
$emptyItems = '<Items\s*/>|<Items>\s*</Items>'

$stamp = Get-Date -Format 'yyyy.MM.dd_HH.mm.ss'

function Get-EntryHashes([string]$path) {
    $hashes = @{}
    $sha = [Security.Cryptography.SHA256]::Create()
    $zip = [IO.Compression.ZipFile]::OpenRead($path)
    try {
        foreach ($entry in $zip.Entries) {
            if ($entry.FullName -match $ignored) { continue }
            $stream = $entry.Open()
            $reader = New-Object IO.StreamReader $stream
            try { $text = $reader.ReadToEnd() } finally { $reader.Dispose() }
            $text = [regex]::Replace($text, $importStamps, '')
            if ($entry.FullName.StartsWith('metadata/') -and $text -match $emptyItems) { continue }
            $hashes[$entry.FullName] = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($text)))
        }
    } finally {
        $zip.Dispose()
        $sha.Dispose()
    }
    return $hashes
}

function Test-SameContents([string]$left, [string]$right) {
    $a = Get-EntryHashes $left
    $b = Get-EntryHashes $right
    if ($a.Count -ne $b.Count) { return $false }
    foreach ($name in $a.Keys) {
        if (-not $b.ContainsKey($name) -or $b[$name] -ne $a[$name]) { return $false }
    }
    return $true
}

# Generates the tenant registration for an export that lacks it, as the version of Dodeca Shell that performed the
# export may predate it. Reserved tenants (___DODECA_*) are registered by the server itself.
function Add-TenantRegistration([string]$path, [string]$tenant) {
    if ($tenant.StartsWith('___')) { return }

    $zip = [IO.Compression.ZipFile]::Open($path, 'Update')
    try {
        if ($null -ne $zip.GetEntry($tenantsEntry)) { return }

        $created = Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'
        $xml = "<?xml version=`"1.0`" encoding=`"UTF-8`"?>`n<DodecaObjects>`n  <Items>`n    <Item>`n" +
            "      <CreatedDate>$created</CreatedDate>`n      <ApplicationId/>`n      <Type>CLASSIC</Type>`n" +
            "      <Status>OPEN</Status>`n    </Item>`n  </Items>`n</DodecaObjects>`n"
        $bytes = (New-Object Text.UTF8Encoding $false).GetBytes($xml)

        $stream = $zip.CreateEntry($tenantsEntry, [IO.Compression.CompressionLevel]::Optimal).Open()
        try { $stream.Write($bytes, 0, $bytes.Length) } finally { $stream.Dispose() }
    } finally {
        $zip.Dispose()
    }
    Write-Host "Tenant registered      : $tenant (generated $tenantsEntry)"
}

$exports = @(Get-ChildItem -Path $AutoImport -Filter '*.zip' -File)
if ($exports.Count -eq 0) {
    Write-Host 'There are no exported tenants to move into place.'
    exit 1
}

foreach ($export in $exports) {
    $tenant = $export.BaseName
    $folder = Join-Path $AutoImport $tenant
    $target = Join-Path $folder $export.Name

    Add-TenantRegistration $export.FullName $tenant

    if (Test-Path $target) {
        if (Test-SameContents $target $export.FullName) {
            Write-Host "Metadata hasn't changed: $($export.Name)"
            Remove-Item $target
        } else {
            Write-Host "Metadata changed       : $($export.Name) will be backed up."
            Move-Item $target (Join-Path $folder "$tenant.$stamp.zip.bak")
        }
    }

    New-Item -ItemType Directory -Force -Path $folder | Out-Null
    Move-Item $export.FullName $target
}

Write-Host
Write-Host 'Successfully exported tenants.'
