@echo off
setlocal EnableDelayedExpansion

:: Starts, stops, and works with the Dodeca server container on this machine. Two generations of server image exist,
:: and this launcher hides the difference: each is detected from the image (or the running container), never from its
:: tag, and each boots through a wrapper script from the scripts folder that adds what the image leaves out.
::
::   standalone - the classic /opt/dodeca image (8.9.x and earlier): the full standalone package with Dodeca Shell and
::                the H2 driver. scripts/wrapper.sh adds the H2 console, imports a mounted license, and imports the
::                clients.
::   server     - the buildpack image (8.10.0 and later): just the server, launched by /cnb/process/web with the
::                repository under /home/cnb and drivers under /workspace/drivers. Dodeca Shell is not in the image, so
::                a mounted license file is handed to the server as its encoded startup license instead, and
::                scripts/wrapper-server.sh adds the H2 console before handing over to the image's own web process.
::                A dshell.jar placed in "%USERPROFILE%\standalone\dodeca\tools" is mounted for "dodeca shell" and
::                "dodeca export".

:: if this is the export command, export every tenant with dshell, move the exports into place on the host, and exit.
if "%1" == "export" (
  call :detect_container || goto :failed
  call :sync_scripts
  !EXEC! /opt/dodeca/scripts/dshell.sh @/opt/dodeca/scripts/export-tenants.dshell || (
    echo.
    echo Failed to export one or more tenants.
    goto :failed
  )
  echo.
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0export-tenants.ps1" -AutoImport "%USERPROFILE%\standalone\dodeca\auto_import"
  exit /b !ERRORLEVEL!
)

:: if this is the shell command, run an interactive dshell script and then exit.
if "%1" == "shell" (
  call :detect_container -it || goto :failed
  call :sync_scripts
  !EXEC! /opt/dodeca/scripts/dshell.sh
  exit /b !ERRORLEVEL!
)

:: if this is the license command, import the mounted license file with dshell and then exit. The server-only image
:: takes the license file when it starts, so there a new license file is a matter of restarting.
if "%1" == "license" (
  call :detect_container -it || goto :failed
  if "!LAYOUT!"=="server" (
    echo This Dodeca server takes the license file from "%USERPROFILE%\standalone\dodeca\license" when it starts.
    echo Run "dodeca stop" and then "dodeca start" to apply a new license file.
    exit /b 0
  )
  call :sync_scripts
  !EXEC! /opt/dodeca/scripts/import-license.sh
  exit /b !ERRORLEVEL!
)

:: if this is the bash command, create an interactive bash shell and then exit.
if "%1" == "bash" (
  call :detect_container -it || goto :failed
  !EXEC! bash
  exit /b !ERRORLEVEL!
)

:: if this is the wait command, wait until the running server is ready and then exit.
if "%1" == "wait" (
  goto :wait
)

:: if this is the start command, set the docker flags for a detached container.
if "%1" == "start" (
  set "FLAGS=-d"
  goto :continue
)

:: if this is the run command, set the docker flags for an interactive container.
if "%1" == "run" (
  set "FLAGS=-it"
  goto :continue
)

if "%1" == "stop" (
  echo Stopping the Dodeca server...

  docker stop dodeca || goto :failed

  echo Done.
  exit /b 0
)

if "%1"=="status" (
  docker ps -a --no-trunc --filter "name=^/dodeca$" --format "table {{.Image}}\t{{.Names}}\t{{.Status}}"
  exit /b !ERRORLEVEL!
)

if "%1"=="follow" (
  docker logs --follow dodeca
  exit /b !ERRORLEVEL!
)

echo No recognized command given for dodeca.
echo Try one of "run", "start", "stop", "wait", "status", "follow", "export", "shell", "license", "bash".
echo.
echo For example: "dodeca start", "dodeca start 8.10.2", "dodeca run 8.9", or "dodeca shell"
exit /b 1

:continue

:: Use the script directory as the working directory.
pushd "%~dp0"

set "HOST_DIR=%USERPROFILE%\standalone\dodeca"

:: If the standalone and dodeca directories does not exist, create them (and copy or update the source folder).
if not exist "%USERPROFILE%\standalone\" mkdir "%USERPROFILE%\standalone\"

if not exist "%HOST_DIR%" (
  robocopy .\dodeca "%HOST_DIR%" /e /nfl /ndl /njh /njs /np
) else (
  robocopy .\dodeca "%HOST_DIR%" /e /nfl /ndl /njh /njs /np /is /im /it /s >nul 2>&1
)

:: earlier launchers mounted a config\wrapper.conf that never existed, which left an empty folder of that name behind.
if exist "%HOST_DIR%\config\wrapper.conf\" rmdir "%HOST_DIR%\config\wrapper.conf" >nul 2>&1

:: set the BRANCH variable (whether or not it was passed). The develop tag is the image of the newest target branch.
if not [%2]==[] (
  set BRANCH=%2
) else (
  set BRANCH=develop
)

:: "latest" was the default before develop and still means the newest image; the registry's own latest tag is no
:: longer published, so it would be a stale image.
if /i "%BRANCH%"=="latest" (
  echo Dodeca latest is the develop image.
  set BRANCH=develop
)

:: set the ENVIRONMENT variable (if one was passed).
if not [%3]==[] (
  set THIRD_ARG=%3
  :: if the third arg contains an equal sign, process it as the ENVIRONMENT variable
  if not "!THIRD_ARG!"=="!THIRD_ARG:==!" (
    set ENVIRONMENT=%~3
    set ENVIRONMENT=-e "!ENVIRONMENT:;=" -e "!"
  )
)

:: a license has to come from somewhere: the license folder, an exported license in auto_import, or an encoded license
:: passed in the environment. Without one the server would start and then refuse every request, so stop here instead.
set "LICENSED="
if exist "%HOST_DIR%\license\dodeca.license" set "LICENSED=1"
if exist "%HOST_DIR%\auto_import\___DODECA_SERVER_LICENSE___\___DODECA_SERVER_LICENSE___.zip" set "LICENSED=1"
echo.%ENVIRONMENT% | findstr /C:"DODECA_ENCODED_STARTUP_LICENSE" >nul 2>&1 && set "LICENSED=1"
if not defined LICENSED (
  echo.
  echo No Dodeca license was found. Copy your dodeca.license file into
  echo.
  echo     %HOST_DIR%\license\
  echo.
  echo and run this command again.
  goto :failed
)

:: if the DODECA_DEPLOY_CLIENTS variable is set to false, do not set a DODECA_DEPLOYMENT_URL.
if "%DODECA_DEPLOY_CLIENTS%" neq "false" (
  :: otherwise, if a DODECA_DEPLOYMENT_URL is not already already defined, set one.
  if not defined DODECA_DEPLOYMENT_URL (
    :: set the DODECA_DEPLOYMENT_HOST variable based on the machine hostname.
    for /f "usebackq" %%a in (`hostname`) do set "DODECA_DEPLOYMENT_HOST=%%a"
    :: use the DODECA_DEPLOYMENT_HOST or localhost to set the DODECA_DEPLOYMENT_URL.
    if "!DODECA_DEPLOYMENT_HOST!" neq "" (
      set "DODECA_DEPLOYMENT_URL=http://!DODECA_DEPLOYMENT_HOST!:8000/dodeca"
    ) else (
      set "DODECA_DEPLOYMENT_URL=http://localhost:8000/dodeca"
    )
  )
)

:: create the standalone network if it doesn't exist...
docker network create --driver bridge standalone > nul 2>&1

:: set the window title if we are running an interactive container.
if "%1"=="run" title Dodeca Server (%BRANCH%)

:: find the image for the requested version, then pull it up front (rather than with --pull always) so that its
:: layout can be inspected before it runs.
call :resolve_image || goto :failed

if "%PULL%"=="1" (
  docker pull "%IMAGE%" || (
    echo Unable to pull %IMAGE%.
    goto :failed
  )
)

call :detect_layout image "%IMAGE%"

:: the docker options shared by both layouts. The server logs at ROOT_LOG_LEVEL (DEBUG unless set in the environment).
if not defined ROOT_LOG_LEVEL set "ROOT_LOG_LEVEL=DEBUG"
set "RUN=docker run --rm --name dodeca %FLAGS% -p 8000:8000 -p 8082:8082 --network=standalone --dns 8.8.8.8 --dns 8.8.4.4 --add-host host.docker.internal:host-gateway"
set "ENV=-e DODECA_ADMIN_ENABLED=true -e DODECA_ADMIN_USERNAME=admin -e DODECA_ADMIN_PASSWORD=password1 -e DODECA_ADMIN_ROLES=USER,ADMIN -e DODECA_AUTO_IMPORT_ON_STARTUP=true -e DODECA_CHECKSUM_FUNCTION=SHA-256 -e DODECA_COMMENTS_AUDIT_LOGGING=true -e DODECA_LANDING_PAGE_LIST_APPS=true -e ROOT_LOG_LEVEL=%ROOT_LOG_LEVEL% -e DODECA_RECOMPUTE_CHECKSUMS_ON_STARTUP=true -e DODECA_UPDATE_SCHEMA_ON_STARTUP=true -e DODECA_XML_LOGGING_LOG_TO_CONSOLE=true -e DSHELL_STARTUP_CONNECTION=local.dodeca.properties"

if "%LAYOUT%"=="server" goto :run_server

:: the standalone layout mounts the package folders into /opt/dodeca and boots through wrapper.sh, which starts the
:: H2 console on 8082, imports a mounted license and the clients with dshell, and signs the ClickOnce manifests.
set "MOUNTS=-v "%HOST_DIR%\auto_import:/opt/dodeca/auto_import" -v "%HOST_DIR%\drivers:/opt/dodeca/drivers" -v "%HOST_DIR%\license:/opt/dodeca/license" -v "%HOST_DIR%\root:/root" -v "%HOST_DIR%\scripts:/opt/dodeca/scripts""

:: run the container with a deployment url, if clients will be deployed,
:: echoing the command to the console.
if "%DODECA_DEPLOY_CLIENTS%" neq "false" (
  call :echo_run %RUN% --entrypoint /opt/dodeca/scripts/wrapper.sh -e "DEPLOYMENT_URL=%DODECA_DEPLOYMENT_URL%" %ENV% %ENVIRONMENT% %MOUNTS% "%IMAGE%"
) else (
  call :echo_run %RUN% --entrypoint /opt/dodeca/scripts/wrapper.sh %ENV% %ENVIRONMENT% %MOUNTS% "%IMAGE%"
)
exit /b %ERRORLEVEL%

:run_server

:: the server-only layout has no Dodeca Shell to import a mounted license file with, so the license file is handed to
:: the server as its encoded startup license through an env file, which the server saves once its repository is ready.
:: An exported license in auto_import, or an encoded license given in the environment, is left to do the job instead.
set "LICENSE_ENV="
if exist "%HOST_DIR%\license\dodeca.license" if not exist "%HOST_DIR%\auto_import\___DODECA_SERVER_LICENSE___\___DODECA_SERVER_LICENSE___.zip" (
  echo.%ENVIRONMENT% | findstr /C:"DODECA_ENCODED_STARTUP_LICENSE" >nul 2>&1 || (
    set "LICENSE_ENV=%TEMP%\dodeca-startup-license.env"
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0encode-license.ps1" -License "%HOST_DIR%\license\dodeca.license" -OutFile "!LICENSE_ENV!" || (
      echo.
      echo The license file %HOST_DIR%\license\dodeca.license could not be read. Replace it and run this command again.
      goto :failed
    )
    set "RUN=!RUN! --env-file "!LICENSE_ENV!""
  )
)

:: The server reads auto_import relative to its /workspace working directory, while the dshell scripts keep their
:: /opt/dodeca paths for both layouts, so the auto_import folder is mounted at both locations. wrapper-server.sh
:: starts the H2 console and then starts the server through the image's own web process.
set "MOUNTS=-v "%HOST_DIR%\auto_import:/workspace/auto_import" -v "%HOST_DIR%\auto_import:/opt/dodeca/auto_import" -v "%HOST_DIR%\drivers:/workspace/drivers" -v "%HOST_DIR%\license:/opt/dodeca/license" -v "%HOST_DIR%\scripts:/opt/dodeca/scripts" -v "%HOST_DIR%\tools:/opt/dodeca/tools""

call :echo_run %RUN% --entrypoint /opt/dodeca/scripts/wrapper-server.sh %ENV% %ENVIRONMENT% %MOUNTS% "%IMAGE%"
set "RC=%ERRORLEVEL%"
if defined LICENSE_ENV del /q "%LICENSE_ENV%" >nul 2>&1
exit /b %RC%

:wait

:: poll the running server's log for the line the license manager writes once the repository is ready and the
:: startup imports are done, for up to %2 seconds (ten minutes by default).
set "LIMIT=%~2"
if not defined LIMIT set "LIMIT=600"
set /a WAITED=0

:wait_loop
docker container inspect dodeca --format "{{.State.Running}}" 2>nul | findstr /c:"true" >nul || (
  echo The Dodeca server is not running.
  goto :failed
)
docker logs dodeca 2>&1 | findstr /c:"License initialized" >nul && (
  echo The Dodeca server is ready.
  exit /b 0
)
if !WAITED! geq !LIMIT! (
  echo The Dodeca server did not become ready within !LIMIT! seconds. "dodeca follow" shows its log.
  goto :failed
)
ping -n 6 127.0.0.1 >nul
set /a WAITED+=5
goto :wait_loop

:resolve_image

:: sets IMAGE to the image for BRANCH and PULL to 1, trying the tag as given, then (for a two-part version) its first
:: patch release, then the Docker Hub images that predate ghcr.io. When none of those can be reached but a copy of the
:: tag is already on this machine, that copy is used without pulling.
set "PULL=1"
set "IMAGE=ghcr.io/appliedolap/dodeca:%BRANCH%"
docker manifest inspect "!IMAGE!" >nul 2>&1 && exit /b 0

call :newest_patch "%BRANCH%"
if defined PATCH_TAG (
  set "IMAGE=ghcr.io/appliedolap/dodeca:!PATCH_TAG!"
  docker manifest inspect "!IMAGE!" >nul 2>&1 && exit /b 0
)

for %%t in ("standalone-%BRANCH%" "standalone-%BRANCH%-latest") do (
  set "IMAGE=appliedolap/dodeca:%%~t"
  docker manifest inspect "!IMAGE!" >nul 2>&1 && exit /b 0
)

set "IMAGE=ghcr.io/appliedolap/dodeca:%BRANCH%"
docker image inspect "!IMAGE!" >nul 2>&1 && (
  echo Dodeca %BRANCH% could not be checked for updates; using the copy already on this machine.
  set "PULL=0"
  exit /b 0
)

echo Dodeca %BRANCH% was not found. Check the version and try again.
exit /b 1

:newest_patch

:: sets PATCH_TAG to X.Y.0 for a two-part version X.Y (%1), the first patch of that version, or leaves it undefined.
set "PATCH_TAG="
set "V=%~1"
set "REST=!V:*.=!"
if "!REST!"=="!V!" exit /b 0
if not "!REST!"=="!REST:.=!" exit /b 0
set "PATCH_TAG=%~1.0"
exit /b 0

:echo_run

:: echo the given command to the console, set off by blank lines, then run it.
echo.
echo %*
echo.
%*
exit /b

:sync_scripts

:: copy the package's container scripts into the mounted scripts folder, so that a container started before this
:: package was installed (or by hand) runs the current scripts.
robocopy "%~dp0dodeca\scripts" "%USERPROFILE%\standalone\dodeca\scripts" /e /nfl /ndl /njh /njs /np /is /im /it >nul 2>&1
exit /b 0

:detect_container

:: the running container sets EXEC to the docker exec prefix its layout needs: the server-only image has to go
:: through the buildpack launcher, which supplies the server's environment and puts java on the PATH. The optional
:: argument holds the docker exec flags: "-it" for the interactive commands, nothing for export, which needs no
:: terminal and so also runs from scripts.
call :detect_layout container dodeca
if not defined LAYOUT (
  echo The Dodeca server is not running.
  exit /b 1
)
if "%LAYOUT%"=="server" (
  set "EXEC=docker exec %~1 dodeca /cnb/lifecycle/launcher"
) else (
  set "EXEC=docker exec %~1 dodeca"
)
exit /b 0

:detect_layout

:: sets LAYOUT to "server" when the image or container (%1) named by %2 was built by buildpacks (its environment
:: carries the buildpack variables, whatever its entrypoint was replaced with), "standalone" for anything else, or
:: leaves it undefined when there is nothing to inspect.
set "LAYOUT="
set "CONFIG_ENV="
for /f "usebackq delims=" %%e in (`docker %1 inspect %2 --format "{{.Config.Env}}" 2^>nul`) do set "CONFIG_ENV=%%e"
if not defined CONFIG_ENV exit /b 0
if not "!CONFIG_ENV!"=="!CONFIG_ENV:CNB_APP_DIR=!" (
  set "LAYOUT=server"
) else (
  set "LAYOUT=standalone"
)
exit /b 0

:failed

:: the exit code of an "exit /b" reached through || inside a command block is lost on the way out to the caller, so
:: the command blocks leave through here when they fail.
exit /b 1
