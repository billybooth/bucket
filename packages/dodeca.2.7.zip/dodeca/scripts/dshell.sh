#!/usr/bin/env bash

# Runs Dodeca Shell against the repository of whichever container this folder is mounted into.
#
# Standalone image (/opt/dodeca): tools/ ships dshell.jar and a local.dodeca.properties that already
# points at the container's H2 repository, and java is on the PATH.
#
# Server-only (buildpack) image: nothing under /opt/dodeca exists in the image. dshell.jar comes from
# the host tools folder that dodeca.cmd mounts at /opt/dodeca/tools (the user copies it there), and
# the connection file is written here from the HIBERNATE_CONNECTION_* environment the server was
# launched with. dodeca.cmd runs this script through /cnb/lifecycle/launcher, which supplies that
# environment and puts java on the PATH.

set -eo pipefail

cd /opt/dodeca/tools

if [ ! -f dshell.jar ]; then
  echo "This Dodeca server image does not include Dodeca Shell."
  echo "Copy dshell.jar into the standalone\\dodeca\\tools folder under your user profile on this machine and try again."
  exit 1
fi

# When the server was launched with an explicit repository connection, point Dodeca Shell at the same one.
if [ -n "${HIBERNATE_CONNECTION_URL}" ]; then
  driver_class="${HIBERNATE_CONNECTION_DRIVER_CLASS}"
  if [ -z "${driver_class}" ] && [[ "${HIBERNATE_CONNECTION_URL}" == jdbc:h2:* ]]; then
    driver_class="org.h2.Driver"
  fi
  {
    [ -n "${driver_class}" ] && echo "hibernate.connection.driver_class=${driver_class}"
    echo "hibernate.connection.url=${HIBERNATE_CONNECTION_URL}"
    echo "hibernate.connection.username=${HIBERNATE_CONNECTION_USERNAME:-sa}"
    echo "hibernate.connection.password=${HIBERNATE_CONNECTION_PASSWORD}"
  } > local.dodeca.properties
fi

# Outside the launcher, the buildpack JRE is not on the PATH.
if ! command -v java > /dev/null 2>&1; then
  buildpack_java="$(find /layers -path '*/bin/java' -print -quit 2> /dev/null)"
  [ -n "${buildpack_java}" ] && export PATH="${PATH}:$(dirname "${buildpack_java}")"
fi

# The launcher's JAVA_TOOL_OPTIONS size the heap and native memory tracking for the server process, not for a shell.
unset JAVA_TOOL_OPTIONS

exec java -Dloader.path="${LOADER_PATH:-/opt/dodeca/drivers}" -jar dshell.jar "$@"
