# Writes a docker --env-file that hands the given Dodeca license file to the server as its encoded startup license:
# the license key (the base64 between the BEGIN and END lines) gzip-compressed and base64-encoded, which is the form of
# DODECA_ENCODED_STARTUP_LICENSE that the server saves as its license once its repository is ready (8.7.0 and later).
param(
    [Parameter(Mandatory)] [string] $License,
    [Parameter(Mandatory)] [string] $OutFile
)

$ErrorActionPreference = 'Stop'

$key = ((Get-Content -LiteralPath $License -Raw) -replace '-----[^-]*-----', '') -replace '\s', ''
if (-not $key) {
    throw "No license key was found in $License."
}

$bytes = [Text.Encoding]::UTF8.GetBytes($key)
$stream = New-Object IO.MemoryStream
$gzip = New-Object IO.Compression.GZipStream($stream, [IO.Compression.CompressionMode]::Compress)
$gzip.Write($bytes, 0, $bytes.Length)
$gzip.Dispose()
$encoded = [Convert]::ToBase64String($stream.ToArray())

# docker reads the file line by line as KEY=VALUE; no BOM, LF only.
[IO.File]::WriteAllText($OutFile, "DODECA_ENCODED_STARTUP_LICENSE=$encoded`n", (New-Object Text.UTF8Encoding $false))
