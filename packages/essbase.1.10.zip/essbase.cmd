@echo off
setlocal

::
:: Copyright (c) 2021, Oracle and/or its affiliates.
:: Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl.
::

:: Use the script directory as the working directory.
pushd "%~dp0"

:: Read the current wrapper version.
if exist "essbase\.volumes\version.txt" (
  for /f "delims=" %%v in (essbase\.volumes\version.txt) do set WRAPPER_VERSION=%%v
) else (
  set WRAPPER_VERSION=0
)

if not defined ESSBASE_HOME set "ESSBASE_HOME=%USERPROFILE%\essbase"

:: if a version.txt exists, read the installed wrapper version out of it.
if exist "%ESSBASE_HOME%\.volumes\version.txt" (
  pushd "%ESSBASE_HOME%\.volumes"
  for /f "delims=" %%v in (version.txt) do set INSTALLED_VERSION=%%v
  popd "%ESSBASE_HOME%\.volumes"
) else (
  set INSTALLED_VERSION=0
)

:: if the defined ESSBASE_HOME doesn't exist, copy the entire source folder there.
if not exist "%ESSBASE_HOME%" (
  robocopy .\essbase "%ESSBASE_HOME%" /e /nfl /ndl /njh /njs /np
) else (
  :: if this is an update (or downgrade), replace all modified files.
  if not "%WRAPPER_VERSION%"=="%INSTALLED_VERSION%" (
    robocopy .\essbase "%ESSBASE_HOME%" /e /nfl /ndl /njh /njs /np /is /im /it /s
  ) else (
    robocopy .\essbase "%ESSBASE_HOME%" /e /nfl /ndl /njh /njs /np /xc /xn /xo /s
  )
)

:: change directory to ESSBASE_HOME
pushd "%ESSBASE_HOME%"

:: if a version was not passed, use the highest version available
if [%2]==[] (
  if exist "%ESSBASE_HOME%" (
    pushd "%ESSBASE_HOME%"
    for /d %%a in (*) do set "ESSBASE_FOLDER_NAME=%%a"
    popd "%ESSBASE_HOME%"
  ) else (
    for /d %%a in (*) do set "ESSBASE_FOLDER_NAME=%%a"
  )
) else (
  set "ESSBASE_FOLDER_NAME=%2"
)

if not exist "%ESSBASE_HOME%\%ESSBASE_FOLDER_NAME%" echo A folder for Essbase %ESSBASE_FOLDER_NAME% must exist in order to use this script. && goto :eof

:: do some .wslconfig validation if the version is 11.1.2.4.
if "%ESSBASE_FOLDER_NAME%"=="11.1.2.4" (
  if not exist "%USERPROFILE%\.wslconfig" (
    setlocal enabledelayedexpansion
    echo In order to run the legacy Essbase 11.1.2.4 docker image, a WSL configuration file must be added.
    choice /C YN /M "Do you want this script to create the required file"
    
    if !ERRORLEVEL! neq 1 goto :eof
    
    echo [wsl2]>                                "%USERPROFILE%\.wslconfig"
    echo kernelCommandLine = vsyscall=emulate>> "%USERPROFILE%\.wslconfig"
    
    echo.
    echo A WSL configuration was created at the following location:
    echo %USERPROFILE%\.wslconfig
    echo.
    echo Please reboot your system in order to load the new configuration.
    goto :eof
  )
)

:: change directory to ESSBASE_HOME\ESSBASE_FOLDER_NAME
pushd "%ESSBASE_HOME%\%ESSBASE_FOLDER_NAME%"

:: capture the STACK_VERISON based on the ESSBASE_FOLDER_NAME,
:: i.e., 11.1.2.4, 21.7
set "STACK_VERSION=%ESSBASE_FOLDER_NAME%"

:: set the STACK_INSTANCE_NAME based on the STACK_VERSION,
:: i.e. essbase-11-1-2-4, essbase-21-6
set "STACK_INSTANCE_NAME=essbase-%STACK_VERSION:.=-%"

:: default values
::if not defined ADMIN_SERVER_PORT       set "ADMIN_SERVER_PORT=7001"
::if not defined ADMIN_SERVER_SSL_PORT   set "ADMIN_SERVER_SSL_PORT=7002"
::if not defined MANAGED_SERVER_PORT     set "MANAGED_SERVER_PORT=9000"
::if not defined MANAGED_SERVER_SSL_PORT set "MANAGED_SERVER_SSL_PORT=9001"

if "%1"=="create" (
  :: create the standalone network if it doesn't exist...
  docker network create --driver bridge standalone > nul 2>&1
  
  echo Creating %STACK_INSTANCE_NAME% stack...
  
  docker compose pull && docker compose --project-name "%STACK_INSTANCE_NAME%" up --detach --force-recreate
  
  if %ERRORLEVEL% neq 0 (
    echo Cleaning up %STACK_INSTANCE_NAME% stack due to failure...
    docker compose --project-name "%STACK_INSTANCE_NAME%" down --volumes
  )
  
  echo Done.
  goto :eof
)

if "%1"=="remove" (
  echo Removing %STACK_INSTANCE_NAME% stack...
  
  docker compose --project-name "%STACK_INSTANCE_NAME%" down --volumes
  
  echo Done.
  goto :eof
)

:: set the window title if we are running an interactive stack.
if "%1"=="run" title Essbase (%STACK_VERSION%)
if "%1"=="run" (
  :: create the standalone network if it doesn't exist...
  docker network create --driver bridge standalone > nul 2>&1
  
  echo Starting %STACK_INSTANCE_NAME% stack...
  
  docker compose --project-name "%STACK_INSTANCE_NAME%" up --no-build
  
  if %ERRORLEVEL% neq 0 (
    echo Stopping %STACK_INSTANCE_NAME% stack due to failure...
    docker compose --project-name "%STACK_INSTANCE_NAME%" stop
  )
  
  goto :eof
)

if "%1"=="start" (
  :: create the standalone network if it doesn't exist...
  docker network create --driver bridge standalone > nul 2>&1
  
  echo Starting %STACK_INSTANCE_NAME% stack...
  
  docker compose --project-name "%STACK_INSTANCE_NAME%" up --detach --no-build
  
  if %ERRORLEVEL% neq 0 (
    echo Stopping %STACK_INSTANCE_NAME% stack due to failure...
    docker compose --project-name "%STACK_INSTANCE_NAME%" stop
  )
  
  echo Done.
  goto :eof
)

if "%1"=="stop" (
  echo Stopping %STACK_INSTANCE_NAME% stack...
  
  docker compose --project-name "%STACK_INSTANCE_NAME%" stop
  
  echo Done.
  goto :eof
)

if "%1"=="status" (
  docker ps -a --no-trunc --filter "name=^/%STACK_INSTANCE_NAME%" --format "table {{.Image}}\t{{.Names}}\t{{.Status}}"
  goto :eof
)

:: if this is the bash command, create an interactive bash shell and then exit.
if "%1" == "bash" (
  docker exec --user 0 -it "%STACK_INSTANCE_NAME%" /bin/bash
  goto :eof
)

:: set the window title if we are following the stack.
if "%1"=="follow" title Essbase (%STACK_VERSION%)
if "%1"=="follow" (
  echo Following %STACK_INSTANCE_NAME% stack...
  
  docker logs --follow "%STACK_INSTANCE_NAME%"
  goto :eof
)

echo No command given for %STACK_INSTANCE_NAME% stack.
echo Try one of "create", "remove", "run", "start", "stop", "bash", "status", "follow".
