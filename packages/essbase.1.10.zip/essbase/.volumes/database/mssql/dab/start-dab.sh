#!/bin/bash
# Starts Data API builder (DAB) inside a SQL Server container and serves one database as a read-only
# MCP server at http://<host>:${DAB_PORT}/mcp. The same script runs in the appliedolap/adventureworks
# image (AdventureWorks MCP) and in the Essbase stacks' database container (Essbase GL MCP).
#
# DAB is the self-contained linux-x64 release, so the container needs no .NET runtime. The image
# has it baked in; the Essbase stacks set DAB_VERSION and DAB_SHA256, and the release is downloaded,
# checked, and extracted into DAB_HOME the first time it is missing there.
#
# Environment:
#   DAB_DATABASE        database to serve (required)
#   DAB_CONFIG          config file (default: dab-config.json beside this script)
#   DAB_HOME            folder holding the release (default: /opt/dab)
#   DAB_PORT            port to listen on (default: 5000)
#   DAB_VERSION         release to download when DAB_HOME has none, such as 2.0.12
#   DAB_SHA256          SHA-256 of that release's dab_net8.0_linux-x64 zip
#   MSSQL_SA_PASSWORD   sa password (or SA_PASSWORD); builds DAB_CONNECTION_STRING for the config
set -u

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
DAB_CONFIG="${DAB_CONFIG:-$SCRIPT_DIR/dab-config.json}"
DAB_HOME="${DAB_HOME:-/opt/dab}"
DAB_PORT="${DAB_PORT:-5000}"
DAB_BINARY="$DAB_HOME/Microsoft.DataApiBuilder"
SA_PWD="${MSSQL_SA_PASSWORD:-${SA_PASSWORD:-}}"
SQLCMD=/opt/mssql-tools18/bin/sqlcmd
[ -x "$SQLCMD" ] || SQLCMD=/opt/mssql-tools/bin/sqlcmd

log() { echo "dab: $*"; }

if [ -z "${DAB_DATABASE:-}" ] || [ -z "$SA_PWD" ]; then
    log "DAB_DATABASE and MSSQL_SA_PASSWORD (or SA_PASSWORD) must be set; not starting." >&2
    exit 1
fi

install_release() {
    if [ -z "${DAB_VERSION:-}" ] || [ -z "${DAB_SHA256:-}" ]; then
        log "$DAB_BINARY is missing and DAB_VERSION/DAB_SHA256 are not set; not starting." >&2
        return 1
    fi

    local url="https://github.com/Azure/data-api-builder/releases/download/v$DAB_VERSION/dab_net8.0_linux-x64-$DAB_VERSION.zip"
    local staging="$DAB_HOME.partial"
    local zip="$staging.zip"

    log "downloading $url"
    rm -rf "$staging" "$zip"
    mkdir -p "$(dirname "$DAB_HOME")"
    if ! wget -q -O "$zip" "$url"; then
        log "download failed." >&2
        rm -f "$zip"
        return 1
    fi
    if ! echo "$DAB_SHA256  $zip" | sha256sum -c --status; then
        log "SHA-256 of the download does not match DAB_SHA256; not starting." >&2
        rm -f "$zip"
        return 1
    fi

    # The image has no unzip; python3 does. zipfile drops the execute bits, so restore them.
    python3 -c 'import sys, zipfile; zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])' "$zip" "$staging" &&
        chmod +x "$staging/Microsoft.DataApiBuilder" "$staging/createdump" &&
        rm -f "$zip" &&
        mv "$staging" "$DAB_HOME" || {
            log "extracting the release failed." >&2
            rm -rf "$staging" "$zip"
            return 1
        }
    log "installed DAB $DAB_VERSION in $DAB_HOME"
}

if [ ! -x "$DAB_BINARY" ]; then
    install_release || exit 1
fi

# Wait up to 120 s for the database to be online.
for _ in $(seq 1 120); do
    if "$SQLCMD" -C -S localhost -U sa -P "$SA_PWD" -l 2 -b -h -1 \
        -Q "SET NOCOUNT ON; IF DATABASEPROPERTYEX(N'$DAB_DATABASE', 'Status') <> 'ONLINE' RAISERROR('offline', 16, 1);" \
        >/dev/null 2>&1; then
        break
    fi
    sleep 1
done

export DAB_CONNECTION_STRING="Server=localhost,1433;Database=$DAB_DATABASE;User Id=sa;Password=$SA_PWD;TrustServerCertificate=True;Application Name=dab"
export ASPNETCORE_URLS="http://+:$DAB_PORT"
export DOTNET_CLI_TELEMETRY_OPTOUT=1

# The mssql user's HOME does not exist, so ASP.NET keeps its data protection keys in the working
# directory. Run from a scratch directory so they stay out of the config's folder, which is a bind
# mount of the Essbase package on the stacks.
WORK_DIR="${TMPDIR:-/tmp}/dab"
mkdir -p "$WORK_DIR" && cd "$WORK_DIR" || exit 1

log "serving $DAB_DATABASE on port $DAB_PORT with $DAB_CONFIG"
exec "$DAB_BINARY" start --config "$DAB_CONFIG" --no-https-redirect
