-- Unlock the built-in Essbase MCP server (Essbase 26+).
-- McpServiceV1 only serves /essbase/rest/v1/ess-mcp when AboutUtil.isMPInstance() is true,
-- which reads the Essbase registry base property OCI == TRUE. Registry rows are base64:
-- OCI = T0NJ, TRUE = VFJVRQ==. Idempotent: safe to run on every database start.
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM ESS1_ESSBASE.ESSBASE_PROPERTIES WHERE NAME = N'T0NJ' AND TYPE = 0)
BEGIN
    INSERT INTO ESS1_ESSBASE.ESSBASE_PROPERTIES (APPLICATION_NAME, DATABASE_NAME, NAME, TYPE, VALUE, EXTENDED_VALUE)
    VALUES (N'ESS_REG:__NO_APP_NAME__', N'ESS_REG:__NO_DB_NAME__', N'T0NJ', 0, N'VFJVRQ==', NULL);
    PRINT 'Essbase registry: OCI=TRUE added (built-in MCP unlocked).';
END
ELSE
    PRINT 'Essbase registry: OCI=TRUE already present.';

-- Also turn on the AI feature flags that OCI deployments derive from OCI=TRUE, so the
-- /essbase/rest/v1/ai/... endpoints and the console's AI features are available. These are
-- derived (TYPE 1) rows the registry only recomputes when its bundled entries file changes, so
-- the update sticks. Deliberately NOT touched: ENCRYPTION_AT_REST and MEMBER_ON_THE_FLY.
-- AI_MDX = QUlfTURY, AI_ASK_ESSBASE = QUlfQVNLX0VTU0JBU0U=, AI_SEMANTIC_SEARCH = QUlfU0VNQU5USUNfU0VBUkNI, AI_CALC = QUlfQ0FMQw==
UPDATE ESS1_ESSBASE.ESSBASE_PROPERTIES
   SET VALUE = N'VFJVRQ=='
 WHERE TYPE = 1
   AND NAME IN (N'QUlfTURY', N'QUlfQVNLX0VTU0JBU0U=', N'QUlfU0VNQU5USUNfU0VBUkNI', N'QUlfQ0FMQw==')
   AND VALUE <> N'VFJVRQ==';
IF @@ROWCOUNT > 0
    PRINT 'Essbase registry: AI feature flags enabled (restart the essbase container to apply).';
ELSE
    PRINT 'Essbase registry: AI feature flags already enabled.';
GO
