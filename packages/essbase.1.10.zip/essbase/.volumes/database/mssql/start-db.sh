#!/bin/bash
#
# Copyright (c) 2021, Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl.
#

SCRIPT_DIR=$(cd $(dirname $0); pwd)

# The compose files make this script the entrypoint, so it runs as PID 1 in place of the image's
# launch_sqlservr.sh (2022 and later), which runs its command in the background and never forwards
# "docker stop" to it. Run the image's permissions check first, as launch_sqlservr.sh does. On the
# 2019 image the check ends with exec "$@", which does nothing without arguments.
if [ -x /opt/mssql/bin/permissions_check.sh ]; then
   /opt/mssql/bin/permissions_check.sh
fi

echo "Starting SQL Server"
/opt/mssql/bin/sqlservr &
pid=$!

# PID 1 ignores signals it does not handle, so without a trap "docker stop" waits out the grace
# period and kills SQL Server. Forward SIGTERM to SQL Server, which shuts down cleanly on it, and
# stop Data API builder (the Essbase GL MCP) with it.
shutdown() {
   echo "Stopping SQL Server"
   pkill -TERM -f Microsoft.DataApiBuilder 2>/dev/null
   kill -TERM "$pid" 2>/dev/null
}
trap shutdown TERM INT

# Configure the database in the background. It must not run in the foreground: bash runs a trap only
# after the foreground command finishes, so a stop during configuration would be ignored.
${SCRIPT_DIR}/configure-db.sh &

# A trapped signal interrupts wait with 128+signal, so wait again for SQL Server's own exit status.
wait $pid
status=$?
if [ $status -gt 128 ]; then
   wait $pid
   status=$?
fi
exit $status
