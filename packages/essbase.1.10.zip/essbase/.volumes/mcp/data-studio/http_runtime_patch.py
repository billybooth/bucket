# Copyright (c) 2025, Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v1.0 as shown at
# https://oss.oracle.com/licenses/upl.

from __future__ import annotations

import logging
import secrets
from typing import Optional

logger = logging.getLogger('oracle-data-studio-mcp')


class InsecureBindRefused(Exception):
    pass


_LOOPBACK_HOSTS = frozenset({'127.0.0.1', '::1', 'localhost', ''})


def is_loopback(host: Optional[str]) -> bool:
    if host is None:
        return True
    return host.strip().lower() in _LOOPBACK_HOSTS


def decide_bind(host: Optional[str], *,
                auth_token: Optional[str] = None,
                allow_insecure_bind: bool = False) -> None:
    if is_loopback(host):
        logger.info('streamable-http bind: loopback (%s) - no auth gate needed', host or '127.0.0.1')
        return
    if auth_token:
        logger.info('streamable-http bind: non-loopback (%s) with MCP_AUTH_TOKEN set - bearer middleware active', host)
        return
    if allow_insecure_bind:
        logger.warning(
            'streamable-http bind: non-loopback (%s) WITHOUT MCP_AUTH_TOKEN - '
            '--allow-insecure-bind acknowledged. Server has NO first-party auth.', host)
        return
    raise InsecureBindRefused(
        'streamable-http refusing to bind to non-loopback host {!r}: '
        'no MCP_AUTH_TOKEN and --allow-insecure-bind not set.'.format(host))


def make_bearer_middleware(token: str):
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.responses import JSONResponse

    expected = token

    class BearerAuthMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request, call_next):
            if request.method == 'GET' and request.url.path in ('/', '/health'):
                return await call_next(request)
            header = request.headers.get('Authorization') or ''
            scheme, _, value = header.partition(' ')
            if scheme.lower() != 'bearer' or not value:
                return JSONResponse(
                    {'error': 'authentication required'}, status_code=401,
                    headers={'WWW-Authenticate': 'Bearer'})
            if not secrets.compare_digest(value, expected):
                return JSONResponse(
                    {'error': 'invalid bearer token'}, status_code=401,
                    headers={'WWW-Authenticate': 'Bearer'})
            return await call_next(request)

    return BearerAuthMiddleware


def wrap_app_with_bearer_auth(app, token: str):
    """Wrap app with bearer-token enforcement using a raw ASGI wrapper.

    Replaces the previous Starlette-remount approach which did not forward
    lifespan events to the inner app, causing the session manager task group
    to never initialise (RuntimeError: Task group is not initialized on every
    request). A raw ASGI callable passes lifespan events through directly
    before any HTTP auth logic runs.
    """
    expected = token

    async def bearer_auth_app(scope, receive, send):
        # Pass lifespan events straight through so the inner app initialises.
        if scope['type'] == 'lifespan':
            await app(scope, receive, send)
            return

        if scope['type'] == 'http':
            method = scope.get('method', '')
            path = scope.get('path', '')

            if method == 'GET' and path in ('/', '/health'):
                await app(scope, receive, send)
                return

            headers = {k.lower(): v for k, v in scope.get('headers', [])}
            auth = headers.get(b'authorization', b'').decode('latin-1')
            scheme, _, value = auth.partition(' ')

            if scheme.lower() != 'bearer' or not value:
                body = b'{"error":"authentication required"}'
                await send({'type': 'http.response.start', 'status': 401,
                            'headers': [(b'content-type', b'application/json'),
                                        (b'www-authenticate', b'Bearer'),
                                        (b'content-length', str(len(body)).encode())]})
                await send({'type': 'http.response.body', 'body': body})
                return

            if not secrets.compare_digest(value, expected):
                body = b'{"error":"invalid bearer token"}'
                await send({'type': 'http.response.start', 'status': 401,
                            'headers': [(b'content-type', b'application/json'),
                                        (b'www-authenticate', b'Bearer'),
                                        (b'content-length', str(len(body)).encode())]})
                await send({'type': 'http.response.body', 'body': body})
                return

        await app(scope, receive, send)

    return bearer_auth_app
