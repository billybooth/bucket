#!/bin/bash
# Installs the oracle-data-studio MCP server into an Essbase 21.x container and applies the two
# local patches it still needs (verified against 1.0.37 on 2026-09-22):
#   http_runtime_patch.py  - bearer-auth wrapper that forwards ASGI lifespan events (upstream's
#                            Starlette remount drops them: "Task group is not initialized")
#   server_patch.py        - disables MCP DNS-rebinding protection when a bearer token is set
#                            (upstream returns 421 "Invalid Host header" behind any proxy/tunnel)
# Runs as root from the compose post_start hook on every container start; idempotent, so only the
# first start after a create pulls anything. The version is pinned because the patches are written
# against specific file contents: bump DATA_STUDIO_VERSION deliberately and re-verify the patches.
set -euo pipefail
script_dir="$(cd "$(dirname "$0")" && pwd)"
version="${DATA_STUDIO_VERSION:-1.0.37}"

if ! command -v oracle-data-studio-mcp >/dev/null 2>&1; then
  echo "Installing python3.11 and oracle-data-studio[mcp]==${version}..."
  yum install -y python3.11 python3.11-pip
  python3.11 -m pip install --quiet "oracle-data-studio[mcp]==${version}"
fi

site="$(python3.11 -c 'import mcp_server, os; print(os.path.dirname(mcp_server.__file__))')"
if ! grep -q 'Replaces the previous Starlette-remount approach' "${site}/http_runtime.py"; then
  cp "${script_dir}/http_runtime_patch.py" "${site}/http_runtime.py"
  rm -f "${site}/__pycache__/http_runtime."*.pyc
  echo "http_runtime.py patched."
fi
python3.11 "${script_dir}/server_patch.py"
echo "oracle-data-studio-mcp $(python3.11 -m pip show oracle-data-studio | sed -n 's/^Version: //p') ready."
