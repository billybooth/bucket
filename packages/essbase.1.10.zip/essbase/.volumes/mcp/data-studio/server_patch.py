"""
Patch oracle-data-studio-mcp server.py to disable DNS rebinding protection
when bearer auth is configured.

Bug: FastMCP initialises TransportSecuritySettings at construction time using
the default host (127.0.0.1), locking allowed_hosts to loopback only. The
oracle-data-studio-mcp server later sets mcp.settings.host = '0.0.0.0' but
never updates transport_security, so requests with a non-loopback Host header
(e.g. from a reverse proxy or tunnel) receive a 421 before bearer auth runs.

Fix: insert one line after mcp.settings.port is set to clear transport_security
when bearer auth is active. Bearer auth already enforces access control, making
DNS rebinding protection redundant in that configuration.
"""
import sys

path = '/usr/local/lib/python3.11/site-packages/mcp_server/server.py'

with open(path) as f:
    src = f.read()

old = '        mcp.settings.host = _config.host\n        mcp.settings.port = _config.port'
new = (
    '        mcp.settings.host = _config.host\n'
    '        mcp.settings.port = _config.port\n'
    '        if _config.auth_token:\n'
    '            from mcp.server.transport_security import TransportSecuritySettings\n'
    '            mcp.settings.transport_security = TransportSecuritySettings(\n'
    '                enable_dns_rebinding_protection=False)'
)

if old not in src:
    print('ERROR: patch target not found in server.py -- package may have changed', file=sys.stderr)
    sys.exit(1)

if new in src:
    print('server.py already patched, skipping.')
    sys.exit(0)

with open(path, 'w') as f:
    f.write(src.replace(old, new, 1))

import os
pyc = path.replace('.py', '.cpython-311.pyc').replace(
    'mcp_server/', 'mcp_server/__pycache__/')
if os.path.exists(pyc):
    os.remove(pyc)

print('server.py patched successfully.')
