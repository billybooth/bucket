@echo off
setlocal

::
:: Copyright (c) 2021, Oracle and/or its affiliates.
:: Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl.
::

:: Use the script directory as the working directory.
pushd "%~dp0"

:: Read the current wrapper version.
if exist "essbase\.volumes\version.txt" (
  for /f "delims=" %%v in (essbase\.volumes\version.txt) do set WRAPPER_VERSION=%%v
) else (
  set WRAPPER_VERSION=0
)

if not defined ESSBASE_HOME set "ESSBASE_HOME=%USERPROFILE%\essbase"

:: if a version.txt exists, read the installed wrapper version out of it.
if exist "%ESSBASE_HOME%\.volumes\version.txt" (
  pushd "%ESSBASE_HOME%\.volumes"
  for /f "delims=" %%v in (version.txt) do set INSTALLED_VERSION=%%v
  popd "%ESSBASE_HOME%\.volumes"
) else (
  set INSTALLED_VERSION=0
)

:: if the defined ESSBASE_HOME doesn't exist, copy the entire source folder there.
if not exist "%ESSBASE_HOME%" (
  robocopy .\essbase "%ESSBASE_HOME%" /e /nfl /ndl /njh /njs /np
) else (
  :: if this is an update (or downgrade), replace all modified files.
  if not "%WRAPPER_VERSION%"=="%INSTALLED_VERSION%" (
    robocopy .\essbase "%ESSBASE_HOME%" /e /nfl /ndl /njh /njs /np /is /im /it /s
  ) else (
    robocopy .\essbase "%ESSBASE_HOME%" /e /nfl /ndl /njh /njs /np /xc /xn /xo /s
  )
)

:: change directory to ESSBASE_HOME
pushd "%ESSBASE_HOME%"

:: if a version was not passed, use the highest version available
set "VERSION_ARG=%2"
if "%1"=="ai" set "VERSION_ARG="
if "%VERSION_ARG%"=="" (
  if exist "%ESSBASE_HOME%" (
    pushd "%ESSBASE_HOME%"
    for /d %%a in (*) do set "ESSBASE_FOLDER_NAME=%%a"
    popd "%ESSBASE_HOME%"
  ) else (
    for /d %%a in (*) do set "ESSBASE_FOLDER_NAME=%%a"
  )
) else (
  set "ESSBASE_FOLDER_NAME=%VERSION_ARG%"
)

if not exist "%ESSBASE_HOME%\%ESSBASE_FOLDER_NAME%" echo A folder for Essbase %ESSBASE_FOLDER_NAME% must exist in order to use this script. && goto :eof

:: do some .wslconfig validation if the version is 11.1.2.4.
if "%ESSBASE_FOLDER_NAME%"=="11.1.2.4" (
  if not exist "%USERPROFILE%\.wslconfig" (
    setlocal enabledelayedexpansion
    echo In order to run the legacy Essbase 11.1.2.4 docker image, a WSL configuration file must be added.
    choice /C YN /M "Do you want this script to create the required file"
    
    if !ERRORLEVEL! neq 1 goto :eof
    
    echo [wsl2]>                                "%USERPROFILE%\.wslconfig"
    echo kernelCommandLine = vsyscall=emulate>> "%USERPROFILE%\.wslconfig"
    
    echo.
    echo A WSL configuration was created at the following location:
    echo %USERPROFILE%\.wslconfig
    echo.
    echo Please reboot your system in order to load the new configuration.
    goto :eof
  )
)

:: change directory to ESSBASE_HOME\ESSBASE_FOLDER_NAME
pushd "%ESSBASE_HOME%\%ESSBASE_FOLDER_NAME%"

:: capture the STACK_VERISON based on the ESSBASE_FOLDER_NAME,
:: i.e., 11.1.2.4, 21.7
set "STACK_VERSION=%ESSBASE_FOLDER_NAME%"

:: set the STACK_INSTANCE_NAME based on the STACK_VERSION,
:: i.e. essbase-11-1-2-4, essbase-21-6
set "STACK_INSTANCE_NAME=essbase-%STACK_VERSION:.=-%"

:: leave the AI containers out when Essbase AI is turned off ("essbase ai off"); only this script's compose calls
:: see this, so other compose projects keep their own profiles.
if /i "%ESSBASE_AI%"=="off" set "COMPOSE_PROFILES=none"

:: add the GPU overlay for the stack's AI model when an NVIDIA GPU is available.
if not defined COMPOSE_FILE if exist "docker-compose.gpu.yml" (
  where nvidia-smi >nul 2>&1 && set "COMPOSE_FILE=docker-compose.yml;docker-compose.gpu.yml"
)

:: default values
::if not defined ADMIN_SERVER_PORT       set "ADMIN_SERVER_PORT=7001"
::if not defined ADMIN_SERVER_SSL_PORT   set "ADMIN_SERVER_SSL_PORT=7002"
::if not defined MANAGED_SERVER_PORT     set "MANAGED_SERVER_PORT=9000"
::if not defined MANAGED_SERVER_SSL_PORT set "MANAGED_SERVER_SSL_PORT=9001"

if "%1"=="ai" goto :ai

if "%1"=="create" (
  :: create the standalone network if it doesn't exist...
  docker network create --driver bridge standalone > nul 2>&1
  
  echo Creating %STACK_INSTANCE_NAME% stack...
  
  docker compose pull && docker compose --project-name "%STACK_INSTANCE_NAME%" up --detach --force-recreate
  
  if %ERRORLEVEL% neq 0 (
    echo Cleaning up %STACK_INSTANCE_NAME% stack due to failure...
    docker compose --project-name "%STACK_INSTANCE_NAME%" down --volumes
  )
  
  echo Done.
  goto :eof
)

if "%1"=="remove" (
  echo Removing %STACK_INSTANCE_NAME% stack...
  
  docker compose --project-name "%STACK_INSTANCE_NAME%" down --volumes
  
  echo Done.
  goto :eof
)

:: set the window title if we are running an interactive stack.
if "%1"=="run" title Essbase (%STACK_VERSION%)
if "%1"=="run" (
  :: create the standalone network if it doesn't exist...
  docker network create --driver bridge standalone > nul 2>&1
  
  echo Starting %STACK_INSTANCE_NAME% stack...
  
  docker compose --project-name "%STACK_INSTANCE_NAME%" up --no-build
  
  if %ERRORLEVEL% neq 0 (
    echo Stopping %STACK_INSTANCE_NAME% stack due to failure...
    docker compose --project-name "%STACK_INSTANCE_NAME%" stop
  )
  
  goto :eof
)

if "%1"=="start" (
  :: create the standalone network if it doesn't exist...
  docker network create --driver bridge standalone > nul 2>&1
  
  echo Starting %STACK_INSTANCE_NAME% stack...
  
  docker compose --project-name "%STACK_INSTANCE_NAME%" up --detach --no-build
  
  if %ERRORLEVEL% neq 0 (
    echo Stopping %STACK_INSTANCE_NAME% stack due to failure...
    docker compose --project-name "%STACK_INSTANCE_NAME%" stop
  )
  
  echo Done.
  goto :eof
)

if "%1"=="stop" (
  echo Stopping %STACK_INSTANCE_NAME% stack...
  
  docker compose --project-name "%STACK_INSTANCE_NAME%" stop
  
  echo Done.
  goto :eof
)

if "%1"=="status" (
  docker ps -a --no-trunc --filter "name=^/%STACK_INSTANCE_NAME%" --format "table {{.Image}}\t{{.Names}}\t{{.Status}}"
  goto :eof
)

:: if this is the bash command, create an interactive bash shell and then exit.
if "%1" == "bash" (
  docker exec --user 0 -it "%STACK_INSTANCE_NAME%" /bin/bash
  goto :eof
)

:: set the window title if we are following the stack.
if "%1"=="follow" title Essbase (%STACK_VERSION%)
if "%1"=="follow" (
  echo Following %STACK_INSTANCE_NAME% stack...
  
  docker logs --follow "%STACK_INSTANCE_NAME%"
  goto :eof
)

echo No command given for %STACK_INSTANCE_NAME% stack.
echo Try one of "create", "remove", "run", "start", "stop", "bash", "status", "follow", "ai".
goto :eof

:: Essbase AI: how the newest stack's AI gateway answers. The settings are user environment variables, so that they
:: survive package updates, which replace the stack's files; each change restarts only the gateway and the model server.
:ai
if /i "%2"=="" goto :ai_status
if /i "%2"=="status" goto :ai_status
if /i "%2"=="local" goto :ai_local
if /i "%2"=="openai" goto :ai_openai
if /i "%2"=="canned" goto :ai_canned
if /i "%2"=="on" goto :ai_on
if /i "%2"=="off" goto :ai_off
echo Unknown option "%2". Try one of "status", "local [7b|14b|model]", "openai [model]", "canned", "on", "off".
goto :eof

:ai_status
docker ps -a --filter "name=^/%STACK_INSTANCE_NAME%-ai-" --format "table {{.Names}}\t{{.Status}}"
set "AI_LINE="
for /f "delims=" %%l in ('docker logs %STACK_INSTANCE_NAME%-ai-gateway 2^>^&1 ^| findstr /c:"AI gateway listening"') do set "AI_LINE=%%l"
if defined AI_LINE echo %AI_LINE%
docker logs %STACK_INSTANCE_NAME%-ai-gateway 2>&1 | findstr /c:"Essbase AI configured" >nul && (echo Essbase AI is ready.) || (echo Essbase AI is not ready.)
goto :eof

:ai_local
set "AI_MODEL=qwen2.5:7b"
if /i "%3"=="14b" set "AI_MODEL=qwen2.5:14b"
if not "%3"=="" if /i not "%3"=="7b" if /i not "%3"=="14b" set "AI_MODEL=%3"
call :ai_set ESSBASE_AI_MODE model
call :ai_unset ESSBASE_AI_CHAT_URL
call :ai_unset ESSBASE_AI_REASONING_EFFORT
call :ai_set ESSBASE_AI_CHAT_MODEL %AI_MODEL%
echo Essbase AI answers with %AI_MODEL% on the stack's model server ^(a new model downloads first^).
goto :ai_apply

:ai_openai
if not defined OPENAI_API_KEY if not defined ESSBASE_AI_CHAT_API_KEY (
  echo Set your OpenAI API key first: setx OPENAI_API_KEY your-key, then open a new window.
  goto :eof
)
set "AI_MODEL=gpt-6-astra"
if not "%3"=="" set "AI_MODEL=%3"
call :ai_set ESSBASE_AI_MODE model
call :ai_set ESSBASE_AI_CHAT_URL https://api.openai.com/v1
call :ai_set ESSBASE_AI_CHAT_MODEL %AI_MODEL%
call :ai_set ESSBASE_AI_REASONING_EFFORT medium
echo Essbase AI answers with OpenAI's %AI_MODEL%. Each question sends its text and matching member names to OpenAI.
goto :ai_apply

:ai_canned
call :ai_set ESSBASE_AI_MODE canned
echo Essbase AI answers from answers.json, for the EssSharp integration tests ^("essbase ai local" switches back^).
goto :ai_apply

:ai_on
call :ai_unset ESSBASE_AI
set "COMPOSE_PROFILES=ai"
echo Starting Essbase AI for %STACK_INSTANCE_NAME%...
docker compose --project-name "%STACK_INSTANCE_NAME%" up --detach --no-build ai-database ai-model ai-gateway
goto :eof

:ai_off
call :ai_set ESSBASE_AI off
echo Stopping Essbase AI for %STACK_INSTANCE_NAME% ^("essbase ai on" starts it again^)...
docker compose --project-name "%STACK_INSTANCE_NAME%" --profile ai stop ai-gateway ai-model ai-database
goto :eof

:: restarts the gateway and the model server with the new settings, if the stack exists; Essbase and the AI database
:: keep running.
:ai_apply
set "AI_GATEWAY_ID="
for /f %%i in ('docker ps -aq --filter "name=^/%STACK_INSTANCE_NAME%-ai-gateway$"') do set "AI_GATEWAY_ID=%%i"
if not defined AI_GATEWAY_ID (
  echo The settings take effect when the stack is next created or started.
  goto :eof
)
docker compose --project-name "%STACK_INSTANCE_NAME%" --profile ai up --detach --no-build --no-deps ai-model ai-gateway
echo The gateway configures Essbase AI again in a minute or two; "essbase ai" shows when it is ready.
goto :eof

:ai_set
setx %1 "%~2" >nul
set "%1=%~2"
goto :eof

:ai_unset
reg delete "HKCU\Environment" /v %1 /f >nul 2>&1
set "%1="
goto :eof
