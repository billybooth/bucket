#!/usr/bin/env bash

# capture the script directory.
script_dir="$(dirname "$(readlink -f "$0")")"

#echo "wait script started at $(date +%r)." >> ~/wrapper.log

# Check if the domain was actually created successfully
domain_marker_success_file=/u01/config/.marker.domain.success

sleep 5

if [ ! -e "$domain_marker_success_file" ]; then
  echo "no domain success marker by $(date +%r); checking every 5 seconds..." >> ~/wrapper.log
fi

while [ ! -e "$domain_marker_success_file" ]; do
  echo -n "." >> ~/wrapper.log
  sleep 5;
done

echo "." >>  ~/wrapper.log
echo "domain created by $(date +%r)." >> ~/wrapper.log

sleep  5

rest_url="http://localhost:$MANAGED_SERVER_PORT/essbase/rest/v1"

if [ ! $(curl --output /dev/null --silent --head --fail --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" "$rest_url/session") ]; then
  echo "no REST service available by $(date +%r); checking every 5 seconds..." >> ~/wrapper.log
fi

until $(curl --output /dev/null --silent --head --fail --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" "$rest_url/session"); do
    echo -n "." >> ~/wrapper.log
    sleep 5
done

echo >> ~/wrapper.log
echo "REST service available by $(date +%r)." >> ~/wrapper.log

sleep 2

echo "Getting session token..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" "$rest_url/session?token=true" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

if [ ! $(curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "accept: application/json" "$rest_url/files/gallery/Applications/Demo Samples/Block Storage" | grep -q Sample_Basic.xlsx) ]; then
  echo "Gallery files not available by $(date +%r); checking every 5 seconds..." >> ~/wrapper.log
fi

until $(curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "accept: application/json" "$rest_url/files/gallery/Applications/Demo Samples/Block Storage" | grep -q Sample_Basic.xlsx); do
  echo -n "." >> ~/wrapper.log
  sleep 5
done

echo >> ~/wrapper.log
echo "Gallery files available for import by $(date +%r)." >> ~/wrapper.log

# import sample basic from the gallery
echo "Importing sample.basic..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/import-sample-basic.json" "$rest_url/jobs" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

# import demo basic from the gallery
echo "Importing demo.basic..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/import-demo-basic.json" "$rest_url/jobs" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

# import asosample basic from the gallery
echo "Importing asosample.basic..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/import-aso-sample.json" "$rest_url/jobs" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 5

if [ $(curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "accept: application/json" "$rest_url/jobs?fullAppName=ASOSamp&systemjobs=false" | grep -q "In Progress") ]; then
  echo "Importing asosample.basic not finished by $(date +%r); checking every 5 seconds..." >> ~/wrapper.log
fi

while $(curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "accept: application/json" "$rest_url/jobs?fullAppName=ASOSamp&systemjobs=false" | grep -q "In Progress"); do
  echo -n "." >> ~/wrapper.log
  sleep 5
done

echo >> ~/wrapper.log
echo "Finished importing asosample.basic by $(date +%r)." >> ~/wrapper.log

# dataload asosamp basic from the gallery
echo "Loading data into asosample.basic..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/dataload-aso-sample.json" "$rest_url/jobs" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

# create drillthrough database connection
echo "Creating connection to SampleBasic database..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/create-drillthrough-connection.json" "$rest_url/connections" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

# create drillthrough datasource
echo "Creating datasource for SampleBasic database..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/create-drillthrough-datasource.json" "$rest_url/datasources" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

# create drillthrough definition
echo "Creating drillthrough for SampleBasic database..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/create-drillthrough-definition.json" "$rest_url/applications/Sample/databases/Basic/reports" >> ~/wrapper.log
echo >> ~/wrapper.log

if [ -f "$script_dir/json/create-drillthrough-connection-oracle.json" ]; then
  sleep 2
  
  # create oracle drillthrough database connection
  echo "Creating connection to oracle SampleBasic database..." >> ~/wrapper.log
  curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/create-drillthrough-connection-oracle.json" "$rest_url/connections" >> ~/wrapper.log
  echo >> ~/wrapper.log
  
  if [ -f "$script_dir/json/create-drillthrough-datasource-oracle.json" ]; then
    sleep 2
    
    # create oracle drillthrough datasource
    echo "Creating datasource for oracle SampleBasic database..." >> ~/wrapper.log
    curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/create-drillthrough-datasource-oracle.json" "$rest_url/datasources" >> ~/wrapper.log
    echo >> ~/wrapper.log
    
    if [ -f "$script_dir/json/create-drillthrough-definition-oracle.json" ]; then
      sleep 2
      
      # create oracle drillthrough definition
      echo "Creating drillthrough for SampleBasic database..." >> ~/wrapper.log
      curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/create-drillthrough-definition-oracle.json" "$rest_url/applications/Sample/databases/Basic/reports" >> ~/wrapper.log
      echo >> ~/wrapper.log
    fi
  fi
fi

# Start the oracle-data-studio MCP server (Essbase 21.x stacks; opt-in via ENABLE_DATA_STUDIO_MCP=TRUE
# on the essbase service). Installation and patching are done as root by the compose post_start hook
# (.volumes/mcp/data-studio/install.sh); this only waits for the binary and starts it on port 9004
# with the stable MCP_AUTH_TOKEN. Essbase 26 stacks leave this off: their token door is the nginx
# proxy in front of the built-in /essbase/rest/v1/ess-mcp endpoint.
if [ "${ENABLE_DATA_STUDIO_MCP^^}" = "TRUE" ]; then
  for i in $(seq 1 120); do
    command -v oracle-data-studio-mcp &>/dev/null && break
    [ $i -eq 1 ] && echo "Waiting for the post_start hook to install oracle-data-studio-mcp (up to 10m)..." >> ~/wrapper.log
    sleep 5
  done
  if command -v oracle-data-studio-mcp &>/dev/null; then
    echo "Starting oracle-data-studio MCP server on port 9004 (profile ${MCP_PROFILE:-admin})..." >> ~/wrapper.log
    nohup oracle-data-studio-mcp --transport streamable-http --host 0.0.0.0 --port 9004 --profile "${MCP_PROFILE:-admin}" >> ~/mcp-server.log 2>&1 &
    echo "oracle-data-studio MCP server started (PID $!)." >> ~/wrapper.log
  else
    echo "oracle-data-studio-mcp not found after 10m; MCP server not started." >> ~/wrapper.log
  fi
fi

# Essbase AI: load the "Embeddings" alias table of each cube that has one (ai-hints/<App>.<Cube>.alt, mounted only on
# stacks with the AI profile). Essbase matches the words of a question to members by their names and aliases, so these
# synonyms ("revenue" for Sales, "states" for Market) steer it to the right members. The alias file goes into the cube's
# folder because MaxL loads alias tables only from there; it is reloaded on every start, so an edited file takes effect.
# The AI setup vectorizes the cubes after the restart below, so it sees the table.
ai_hints_dir="$script_dir/ai-hints"
maxl_shell=$(find /u01/config/domains -path '*/esstools/bin/startMAXL.sh' 2>/dev/null | head -1)
if [ -d "$ai_hints_dir" ] && [ -n "$maxl_shell" ]; then
  for alias_file in "$ai_hints_dir"/*.*.alt; do
    [ -e "$alias_file" ] || continue
    cube_name=$(basename "$alias_file" .alt)
    app_name=${cube_name%%.*}
    db_name=${cube_name#*.}
    curl --silent --output /dev/null --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -X PUT \
      -H "Content-Type: application/octet-stream" --data-binary @"$alias_file" \
      "$rest_url/files/applications/$app_name/$db_name/embeddings.alt?overwrite=true"
    maxl_script=$(mktemp)
    cat > "$maxl_script" <<EOF
login "$ADMIN_USERNAME" "$ADMIN_PASSWORD" on localhost;
alter database "$app_name"."$db_name" unload alias_table "Embeddings";
alter database "$app_name"."$db_name" load alias_table "Embeddings" from data_file "embeddings.alt";
logout;
EOF
    if "$maxl_shell" "$maxl_script" 2>&1 | grep -q "Database $app_name.$db_name altered"; then
      echo "Loaded the Embeddings alias table of $app_name.$db_name by $(date +%r)." >> ~/wrapper.log
    else
      echo "Could not load the Embeddings alias table of $app_name.$db_name by $(date +%r)." >> ~/wrapper.log
    fi
    rm -f "$maxl_script"
  done
fi

# Essbase 26+: apply the AI feature flags the database container sets in the Essbase registry (enable-mcp.sql).
# They are set after Essbase first reads its registry, and Essbase keeps what it read until it restarts, so restart
# the Essbase managed server (not the container) through WebLogic when Essbase still reports AI as off. This runs
# last, so nothing above is interrupted. Older versions have no AI endpoints and never match.
ai_probe() {
  curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -X POST     "$rest_url/ai/applications/Sample/databases/Basic/listSampleQueries" | grep -q -E "Registry setting|No registry is enabled"
}
if ai_probe; then
  wls_url="http://localhost:${ADMIN_SERVER_PORT:-7001}/management/weblogic/latest/domainRuntime/serverLifeCycleRuntimes/essbase_server1"
  wls() {
    curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "X-Requested-By: essbase-setup"       -H "Accept: application/json" -H "Content-Type: application/json" "$@"
  }
  wls_state() { wls "$wls_url?fields=state&links=none" | grep -o '"state"[^,}]*' | grep -o '[A-Z_]*"$' | tr -d '"'; }

  echo "Restarting the Essbase server to apply its AI registry settings by $(date +%r)..." >> ~/wrapper.log
  wls -X POST -d '{"timeout":120,"ignoreSessions":true}' "$wls_url/shutdown" > /dev/null
  for i in $(seq 1 120); do [ "$(wls_state)" = "SHUTDOWN" ] && break; sleep 5; done
  wls -X POST -d '{}' "$wls_url/start" > /dev/null
  for i in $(seq 1 180); do [ "$(wls_state)" = "RUNNING" ] && break; sleep 5; done
  until curl --output /dev/null --silent --head --fail --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" "$rest_url/session"; do
    sleep 5
  done

  if ai_probe; then
    echo "Essbase still reports AI as off after the restart by $(date +%r)." >> ~/wrapper.log
  else
    echo "Essbase AI registry settings applied by $(date +%r)." >> ~/wrapper.log
  fi
fi

echo "Done" >> ~/wrapper.log
