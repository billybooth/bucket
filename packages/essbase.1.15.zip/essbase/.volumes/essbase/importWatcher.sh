#!/usr/bin/env bash

# Loads what is dropped into the imports folder (.volumes/essbase/imports on the host) into this Essbase server, then
# keeps watching the folder and loads new or changed drops. Each subfolder is the application its files load into,
# whatever names the files carry inside:
#
#   imports/<App>/<Any>.zip      LCM export of one application (21+), imported as <App>
#   imports/<Any>.zip            LCM export of several applications (21+), each under its own name
#   imports/<App>/<Cube>.xlsx    DBX application workbook (21+), imported as <App>.<Cube>; a .zip of the same name
#                                beside it holds the workbook's separate data
#   imports/<App>/<Cube>.otl     outline; ASO or BSO and the Unicode mode are read from the file
#   imports/<App>/<Cube>.txt     data export (<Cube>_2.txt and so on for a split export), loaded after the outline
#
# A drop replaces the cube it names. When anything in an application's folder changes, the whole folder loads again in
# order: LCM exports, then workbooks, outlines, and data, so outlines and data apply on top of an LCM or workbook
# import. A file loads once it stops changing between two polls. Progress goes to ~/imports.log.

# capture the script directory.
script_dir="$(dirname "$(readlink -f "$0")")"

imports_dir="$script_dir/imports"
state_file="$HOME/.imports-state"
log_file="$HOME/imports.log"
poll_seconds="${IMPORTS_POLL_SECONDS:-15}"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$log_file"
}

# only one watcher per container, even if the setup script runs again.
exec 9> "$HOME/.imports.lock"
flock --nonblock 9 || exit 0

# if this is a 21+ container...
if [ -d /u01 ]; then
  modern=true
  admin_user="${ADMIN_USERNAME:-admin}"
  admin_password="$ADMIN_PASSWORD"
  maxl_shell=$(find /u01/config/domains -path '*/esstools/bin/startMAXL.sh' 2>/dev/null | head -1)
  app_root="${ARBORPATH:-/u01/data/essbase}/app"
  rest_url="http://localhost:${MANAGED_SERVER_PORT:-9000}/essbase/rest/v1"
  jar=$(ls /usr/java/*/bin/jar 2>/dev/null | head -1)
# otherwise, if this is an 11.1.2.4 container...
else
  modern=false
  admin_user="${EPM_ADMIN:-admin}"
  admin_password="$EPM_PASSWORD"
  essbase_instance="$USER_PROJECTS/epmsystem1/EssbaseServer/essbaseserver1"
  maxl_shell="$essbase_instance/bin/startMaxl.sh"
  app_root="$essbase_instance/app"
fi

# runs MaxL statements; the output is left in maxl_output, and the result is false when any statement failed.
maxl() {
  local script
  script=$(mktemp)
  {
    echo "login \"$admin_user\" \"$admin_password\" on localhost;"
    printf '%s\n' "$@"
    echo "logout;"
  } > "$script"
  maxl_output=$("$maxl_shell" "$script" 2>&1)
  rm -f "$script"
  ! echo "$maxl_output" | grep -q "ERROR - "
}

maxl_errors() {
  if echo "$maxl_output" | grep -q "1042026"; then
    echo "Essbase has no free ports to start another application; unload or delete one and drop the file again."
  else
    echo "$maxl_output" | grep "ERROR - " | sed 's/^ *//' | tr '\n' ' '
  fi
}

rest() {
  curl --silent --user "$admin_user:$admin_password" "$@"
}

# prints a name the files catalog accepts for an upload: it refuses special characters, including a second dot.
upload_name() {
  echo "imports_$(echo "$1" | tr -c 'A-Za-z0-9_\n' '_').$2"
}

# uploads a file to the admin user's folder in the files catalog.
upload() {
  [ "$(rest --output /dev/null --write-out '%{http_code}' -X PUT -H "Content-Type: application/octet-stream" \
    --data-binary @"$1" "$rest_url/files/users/$admin_user/$2?overwrite=true")" = "200" ]
}

remove_upload() {
  rest --output /dev/null -X DELETE "$rest_url/files/users/$admin_user/$1"
}

# runs a REST job and waits up to an hour for it; the result is true when it completed, and job_error holds the
# server's message otherwise.
run_job() {
  local reply id status i
  reply=$(rest -H "Content-Type: application/json" -d "$1" "$rest_url/jobs")
  id=$(echo "$reply" | grep -o '"job_ID" *: *[0-9]*' | grep -o '[0-9]*$')
  if [ -z "$id" ]; then
    job_error="$reply"
    return 1
  fi
  for i in $(seq 1 720); do
    reply=$(rest "$rest_url/jobs/$id")
    status=$(echo "$reply" | grep -o '"statusMessage" *: *"[^"]*"' | head -1 | sed 's/.*: *"//; s/"$//')
    case "$status" in
      "In Progress"|"Not Started"|"") sleep 5 ;;
      *) break ;;
    esac
  done
  job_error=$(echo "$reply" | grep -o '"errorMessage" *: *"\([^"\\]\|\\.\)*' | head -1 |
    sed 's/^"errorMessage" *: *"//; s/\\n$//; s/\\"/"/g')
  [ "$status" = "Completed" ]
}

# prints aso, bso-unicode, or bso-native for an outline file. Block storage outlines start with "ABDV1" and carry
# 01 (native) or 02 (Unicode) in their seventh byte; aggregate storage outlines use the paged format instead.
outline_kind() {
  local header
  header=$(head -c 7 "$1" | od -A n -t x1 | tr -d ' \n')
  case "$header" in
    4142445631??02) echo bso-unicode ;;
    4142445631*) echo bso-native ;;
    *) echo aso ;;
  esac
}

# prints the path of a cube's outline on the server, or nothing when the cube has none yet. 26.1 keeps block storage
# outlines in a cube/ subfolder.
server_outline() {
  local path
  for path in "$app_root/$1/$2/cube/$2.otl" "$app_root/$1/$2/$2.otl"; do
    if [ -f "$path" ]; then
      echo "$path"
      return
    fi
  done
}

# prints the kind of an application already on the server, read from any of its outlines.
server_app_kind() {
  local path
  path=$(find "$app_root/$1" -maxdepth 3 -name '*.otl' 2>/dev/null | head -1)
  [ -n "$path" ] && outline_kind "$path"
}

load_outline() {
  local app="$1" cube="$2" file="$3" kind app_kind target
  kind=$(outline_kind "$file")
  app_kind=$(server_app_kind "$app")

  if [ ! -d "$app_root/$app" ]; then
    case "$kind" in
      aso) maxl "create application \"$app\" using aggregate_storage;" ;;
      bso-unicode) maxl "create application \"$app\" type unicode_mode;" ;;
      bso-native) maxl "create application \"$app\" type nonunicode_mode;" ;;
    esac || { log "Could not create application $app: $(maxl_errors)"; return 1; }
  elif [ -n "$app_kind" ] && [ "${app_kind%%-*}" != "${kind%%-*}" ]; then
    log "Skipped $app/$cube.otl: it is a ${kind%%-*} outline, and application $app is ${app_kind%%-*}."
    return 1
  fi

  if [ -z "$(server_outline "$app" "$cube")" ]; then
    maxl "create database \"$app\".\"$cube\";" || { log "Could not create cube $app.$cube: $(maxl_errors)"; return 1; }
  else
    # clear the cube's data, which would not fit the new outline.
    if [ "$kind" = aso ]; then
      maxl "alter database \"$app\".\"$cube\" reset all;"
    else
      maxl "alter database \"$app\".\"$cube\" reset;"
    fi || log "Could not clear the data of $app.$cube: $(maxl_errors)"
  fi

  maxl "alter system unload application \"$app\";"
  if [ "$app_kind" = bso-native ] && [ "$kind" = bso-unicode ]; then
    maxl "alter application \"$app\" set type unicode_mode;" ||
      { log "Could not convert application $app to Unicode for $cube.otl: $(maxl_errors)"; return 1; }
  fi

  target=$(server_outline "$app" "$cube")
  cp "$file" "$target" && rm -f "$target.keep"
  if maxl "alter system load application \"$app\";"; then
    log "Loaded the outline of $app.$cube ($kind)."
  else
    log "Could not load the outline of $app.$cube: $(maxl_errors)"
    return 1
  fi
}

# loads Essbase data exports into a cube, then calculates a block storage cube, since a level 0 export holds no totals.
load_data() {
  local app="$1" cube="$2" outline file name cells loaded=false
  shift 2
  outline=$(server_outline "$app" "$cube")
  if [ -z "$outline" ]; then
    log "Skipped the data for $app.$cube: the cube does not exist; drop its outline, workbook, or LCM export too."
    return 1
  fi
  for file in "$@"; do
    name="imports.$(basename "$file")"
    # a Unicode export starts with a UTF-8 marker, which a non-Unicode cube refuses; plain ASCII text loads without it.
    if [ "$(outline_kind "$outline")" = bso-native ] && [ "$(head -c 3 "$file" | od -A n -t x1 | tr -d ' ')" = efbbbf ]; then
      if [ "$(tail -c +4 "$file" | LC_ALL=C tr -d '\000-\177' | head -c 1 | wc -c)" -ne 0 ]; then
        log "Skipped $(basename "$file"): it is a Unicode export with non-ASCII text, and $app.$cube is not Unicode."
        continue
      fi
      tail -c +4 "$file" > "$app_root/$app/$cube/$name"
    else
      cp "$file" "$app_root/$app/$cube/$name"
    fi
    if maxl "import database \"$app\".\"$cube\" data from server data_file \"$name\" on error abort;"; then
      cells=$(echo "$maxl_output" | grep -io 'updated *\[[0-9]*\] cells' | head -1 | grep -o '[0-9]*')
      log "Loaded $(basename "$file") into $app.$cube${cells:+ ($cells cells updated)}."
      loaded=true
    else
      log "Could not load $(basename "$file") into $app.$cube: $(maxl_errors)"
    fi
    rm -f "$app_root/$app/$cube/$name"
  done
  [ "$loaded" = true ] && calculate "$app" "$cube"
}

# runs the default calculation of a block storage cube, so its loaded level 0 data rolls up; aggregate storage cubes
# need none.
calculate() {
  [ "$(outline_kind "$(server_outline "$1" "$2")")" != aso ] || return 0
  if maxl "execute calculation default on \"$1\".\"$2\";"; then
    log "Calculated $1.$2."
  else
    log "Could not calculate $1.$2: $(maxl_errors)"
  fi
}

# deletes a cube a workbook replaces; Essbase refuses while the cube is busy, so this unloads the application and
# tries again once.
delete_cube() {
  [ -n "$(server_outline "$1" "$2")" ] || return 0
  [ "$(rest --output /dev/null --write-out '%{http_code}' -X DELETE "$rest_url/applications/$1/databases/$2")" = 204 ] &&
    return 0
  maxl "alter system unload application \"$1\";"
  [ "$(rest --output /dev/null --write-out '%{http_code}' -X DELETE "$rest_url/applications/$1/databases/$2")" = 204 ] &&
    return 0
  log "Could not delete $1.$2 to replace it with $2.xlsx."
  return 1
}

import_workbook() {
  run_job "{\"jobtype\":\"importExcel\",\"application\":\"$1\",\"db\":\"$2\",\"parameters\":{
    \"catalogExcelPath\":\"/users/$admin_user/$3\",\"importExcelFileName\":\"$3\",\"loaddata\":\"$4\",
    \"recreateApplication\":\"false\",\"createFiles\":\"true\",\"executeScript\":\"false\",\"buildOption\":\"NONE\"}}"
}

load_workbook() {
  local app="$1" cube="$2" file="$3" data_zip="$4" name extract_dir imported=false with_data=false
  name=$(upload_name "${app}_$cube" xlsx)
  delete_cube "$app" "$cube" || return 1
  upload "$file" "$name" || { log "Could not upload $app/$cube.xlsx."; return 1; }
  # a workbook whose data comes in a separate zip has none of its own, and asking for it fails the import.
  if [ -n "$data_zip" ]; then
    import_workbook "$app" "$cube" "$name" false && imported=true
  elif import_workbook "$app" "$cube" "$name" true; then
    imported=true
    with_data=true
  elif echo "$job_error" | grep -q "Data source details not found"; then
    delete_cube "$app" "$cube" && import_workbook "$app" "$cube" "$name" false && imported=true
  fi
  if $imported; then
    log "Imported the workbook $cube.xlsx as $app.$cube."
  else
    log "Could not import the workbook $cube.xlsx as $app.$cube: $job_error"
    remove_upload "$name"
    return 1
  fi
  remove_upload "$name"

  if [ -n "$data_zip" ]; then
    extract_dir=$(mktemp -d)
    (cd "$extract_dir" && "$jar" xf "$data_zip")
    load_data "$app" "$cube" $(find "$extract_dir" -type f | sort)
    rm -rf "$extract_dir"
  elif $with_data; then
    calculate "$app" "$cube"
  fi
}

# prints the applications an LCM export holds (the top folders that contain Databases/), one per line.
lcm_applications() {
  "$jar" tf "$1" 2>/dev/null | grep -o '^[^/]*/Databases/' | cut -d/ -f1 | sort -u
}

load_lcm() {
  local file="$1" target="$2" name parameters source
  name=$(upload_name "$(basename "${file%.*}")" zip)
  source=$(lcm_applications "$file" | tr '\n' ' ')
  parameters="\"zipFileName\":\"$name\",\"overwrite\":\"true\""
  [ -n "$target" ] && parameters="$parameters,\"targetApplicationName\":\"$target\""
  upload "$file" "$name" || { log "Could not upload $(basename "$file")."; return 1; }
  if run_job "{\"jobtype\":\"lcmImport\",\"parameters\":{$parameters}}"; then
    if [ -n "$target" ]; then
      log "Imported the LCM export of ${source% } as $target."
    else
      log "Imported the LCM export of ${source% }."
    fi
  else
    log "Could not import the LCM export $(basename "$file"): $job_error"
  fi
  remove_upload "$name"
}

# loads one application's folder in order: LCM exports, workbooks, outlines, then data.
load_application() {
  local app="$1" folder="$imports_dir/$1" file name cube base apps
  local -a lcm_files=() workbooks=() outlines=()
  local -A data_files=()

  for file in "$folder"/*; do
    [ -f "$file" ] || continue
    name=$(basename "$file")
    case "${name,,}" in
      *.otl) outlines+=("$file") ;;
      *.xlsx) workbooks+=("$file") ;;
      *.txt)
        base="${name%.*}"
        cube="$base"
        # a split export's later files end in _2, _3, and so on.
        if [[ "$base" =~ ^(.+)_[0-9]+$ ]] && [ ! -f "$folder/$base.otl" ] && [ ! -f "$folder/$base.xlsx" ] &&
          [ -z "$(server_outline "$app" "$base")" ]; then
          cube="${BASH_REMATCH[1]}"
        fi
        data_files[$cube]="${data_files[$cube]}$file"$'\n'
        ;;
      *.zip)
        # a zip with a workbook of the same name holds that workbook's data.
        [ -f "${file%.*}.xlsx" ] && continue
        if ! $modern; then
          log "Skipped $app/$name: Essbase 11.1.2.4 takes outlines and data exports only."
          continue
        fi
        apps=$(lcm_applications "$file" | wc -l)
        if [ "$apps" -eq 1 ]; then
          lcm_files+=("$file")
        elif [ "$apps" -gt 1 ]; then
          log "Skipped $app/$name: it holds several applications; move it to the top of the imports folder."
        else
          log "Skipped $app/$name: it is not an LCM export, and no workbook named ${name%.*}.xlsx is beside it."
        fi
        ;;
      *.pag|*.ind|*.dat|*.esm|*.tct|*.db|*.dbb)
        log "Skipped $app/$name: storage files do not move between servers; ask for a data export (.txt) instead."
        ;;
      *) log "Skipped $app/$name: not an outline, workbook, LCM export, or data export." ;;
    esac
  done

  if ! $modern && [ ${#workbooks[@]} -gt 0 ]; then
    log "Skipped the workbooks in $app: Essbase 11.1.2.4 takes outlines and data exports only."
    workbooks=()
  fi

  for file in "${lcm_files[@]}"; do
    load_lcm "$file" "$app"
  done
  for file in "${workbooks[@]}"; do
    name=$(basename "$file")
    if [ -f "${file%.*}.zip" ]; then
      load_workbook "$app" "${name%.*}" "$file" "${file%.*}.zip"
    else
      load_workbook "$app" "${name%.*}" "$file"
    fi
  done
  for file in "${outlines[@]}"; do
    name=$(basename "$file")
    load_outline "$app" "${name%.*}" "$file"
  done
  for cube in "${!data_files[@]}"; do
    local -a files=()
    while IFS= read -r file; do
      [ -n "$file" ] && files+=("$file")
    done <<< "$(printf '%s' "${data_files[$cube]}" | sort)"
    load_data "$app" "$cube" "${files[@]}"
  done

  # 11.1.2.4 has few ports for running applications; Essbase starts an application again when it is next used.
  if ! $modern && [ -d "$app_root/$app" ]; then
    maxl "alter system unload application \"$app\";"
  fi
}

# a file's signature changes whenever it is written.
signature() {
  stat -c '%s.%Y' "$1" 2>/dev/null
}

declare -A seen=() loaded=()
if [ -f "$state_file" ]; then
  while IFS='|' read -r path sig; do
    [ -n "$path" ] && loaded[$path]="$sig"
  done < "$state_file"
fi

save_state() {
  local path
  for path in "${!loaded[@]}"; do
    echo "$path|${loaded[$path]}"
  done > "$state_file"
}

# wait for Essbase to accept a login; 11.1.2.4 also finishes loading its sample cubes first.
until maxl; do
  sleep 30
done
if ! $modern; then
  until [ -f "$HOME/.hasBeenConfigured" ]; do
    sleep 30
  done
fi
log "Watching $imports_dir every $poll_seconds seconds."

while :; do
  if [ -d "$imports_dir" ]; then
    changed_apps=()
    changed_zips=()
    pending=false

    for file in "$imports_dir"/*.zip "$imports_dir"/*/*; do
      [ -f "$file" ] || continue
      path="${file#$imports_dir/}"
      sig=$(signature "$file")
      [ "${loaded[$path]}" = "$sig" ] && continue
      # wait until the file stops changing, so a copy in progress is not loaded.
      if [ "${seen[$path]}" != "$sig" ]; then
        seen[$path]="$sig"
        pending=true
        continue
      fi
      case "$path" in
        */*) changed_apps+=("${path%%/*}") ;;
        *) changed_zips+=("$file") ;;
      esac
    done

    # load an application's folder only when every file in it is settled.
    if ! $pending; then
      for file in "${changed_zips[@]}"; do
        if ! $modern; then
          log "Skipped $(basename "$file"): Essbase 11.1.2.4 takes outlines and data exports only."
        elif [ "$(lcm_applications "$file" | wc -l)" -gt 0 ]; then
          load_lcm "$file"
        else
          log "Skipped $(basename "$file"): only LCM exports go at the top of the imports folder."
        fi
        loaded[${file#$imports_dir/}]=$(signature "$file")
      done
      for app in $(printf '%s\n' "${changed_apps[@]}" | sort -u); do
        load_application "$app"
        for file in "$imports_dir/$app"/*; do
          [ -f "$file" ] && loaded[${file#$imports_dir/}]=$(signature "$file")
        done
      done
      [ ${#changed_zips[@]} -gt 0 ] || [ ${#changed_apps[@]} -gt 0 ] && save_state
    fi
  fi
  [ -n "$IMPORTS_ONCE" ] && ! $pending && break
  # the sleep must not inherit the lock, or a watcher started right after this one stops would find it still held.
  sleep "$poll_seconds" 9>&-
done
