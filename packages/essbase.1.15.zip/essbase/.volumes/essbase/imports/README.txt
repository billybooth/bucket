Drop Essbase files here to load them into the running Essbase stack. Each stack watches this folder, loads
what it finds when it starts, and loads new or changed files within a few seconds of their copy finishing.

Each subfolder is the application its files load into, whatever names the files carry inside:

  <App>\<Cube>.otl     outline; ASO or BSO and the Unicode mode are read from the file
  <App>\<Cube>.txt     Essbase data export, loaded after the outline (<Cube>_2.txt and so on for a split export)
  <App>\<Cube>.xlsx    DBX application workbook (21.x and later); a <Cube>.zip beside it holds its separate data
  <App>\<Any>.zip      LCM export of one application (21.x and later), imported as <App>
  <Any>.zip            LCM export of several applications (21.x and later), each under its own name

A drop replaces the cube it names. When anything in an application's folder changes, the whole folder loads again:
LCM exports first, then workbooks, outlines, and data. Block storage cubes are calculated after their data loads.
Essbase 11.1.2.4 takes outlines and data exports only.
Storage files (.pag, .ind, .dat) are skipped: they do not move between servers, so ask for a data export instead.

Progress goes to ~/imports.log inside the Essbase container ("essbase bash", then "cat ~/imports.log").

A stack created before version 1.13 of this package does not see this folder. Remove it and create it again
("essbase remove <version>", then "essbase create <version>"); removing a stack deletes its applications.
