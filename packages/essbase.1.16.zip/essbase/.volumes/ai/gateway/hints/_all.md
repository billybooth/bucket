These rules refine the instructions that follow. Where the two disagree, these rules win.

1. A dimension, level or kind of member named after "by", "per", "each", "every", "for each" or "broken down by" asks for its members, not its total. Give it a hierarchy_scope even though no scope keyword is written: "children" for the level just below the member (for example "by market" is Market with "children"), or "leaves" when the words name the lowest level (for example "by state" or "each month").
2. "Across all X", "for all X", "overall X" and "total X" ask for the total of X: write X itself with an empty hierarchy_scope (for example "across all markets" is Market with "").
3. A plural word that names a kind of member, such as "states", "regions", "products" or "months", asks for all members of that kind, with the hierarchy_scope that rule 1 would give it.
4. "Compare A and B" asks for A and B side by side: list both members and use the "difference" operator only when the question asks for a difference, variance or gap.
5. Interpret relative dates ("last year", "this quarter") only when the outline has members for them. When it does not, keep the words as written and let them name the time dimension.
6. When a section below names the levels of a dimension, use it to choose the member and hierarchy_scope. A cube's own notes take precedence over these rules.

Worked examples of these rules (the member names are only illustrations):

Question: "Compare actual and budget sales for each region."
{"operator":"none","operands":[],"sort":{},"POV":{"Scenario":[{"member_name":"actual","hierarchy_scope":""},{"member_name":"budget","hierarchy_scope":""}],"Measures":[{"member_name":"sales","hierarchy_scope":""}],"Market":[{"member_name":"market","hierarchy_scope":"children"}]}}
info: Actual and budget sales side by side for each region.

Question: "What is the difference between actual and budget sales?"
{"operator":"difference","operands":[{"member_name":"actual","hierarchy_scope":""},{"member_name":"budget","hierarchy_scope":""}],"sort":{"Measures":[{"member_name":"sales","hierarchy_scope":""}]},"POV":{"Measures":[{"member_name":"sales","hierarchy_scope":""}]}}
info: Actual sales minus budget sales.

Question: "Show profit by product."
{"operator":"none","operands":[],"sort":{},"POV":{"Measures":[{"member_name":"profit","hierarchy_scope":""}],"Product":[{"member_name":"product","hierarchy_scope":"children"}]}}
info: Profit for each member directly below Product.
