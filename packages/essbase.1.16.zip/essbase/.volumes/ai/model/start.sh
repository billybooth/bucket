#!/bin/sh
#
# Serves the Ollama models the stack's AI gateway answers with, pulling any that are missing (the first
# start of a stack downloads them into the stack's model volume).

set -eu

# The health check reports ready once this file exists.
rm -f /tmp/models-ready

ollama serve &
server=$!
trap 'kill -TERM "$server" 2>/dev/null' TERM INT

until ollama list > /dev/null 2>&1; do
  sleep 1
done

# A chat model served elsewhere (AI_CHAT_URL) is not pulled.
models="${AI_EMBED_MODEL_NAME:-}"
[ -n "${AI_CHAT_URL:-}" ] || models="${AI_CHAT_MODEL_NAME:-} $models"

for model in $models; do
  case "$model" in *:*) name="$model" ;; *) name="$model:latest" ;; esac
  if ollama list | awk 'NR > 1 { print $1 }' | grep -qxF "$name"; then
    echo "Model $name is present"
  else
    echo "Pulling model $name"
    ollama pull "$model"
  fi
done
echo "Models ready: $models"
touch /tmp/models-ready

wait "$server"
