#!/bin/bash
#
# Copyright (c) 2021, Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl.
#

SCRIPT_DIR=$(cd $(dirname $0); pwd)

# Add both variants of the microsoft ODBC tools path to the path
export PATH="${PATH:+${PATH}:}/opt/mssql-tools/bin"
export PATH="${PATH:+${PATH}:}/opt/mssql-tools18/bin"

# Sleep for 30 seconds to give the database a chance to start up
sleep 30

# Wait up to 10 minutes for SQL Server to answer, with every database online: SUM(state) is 0 then.
# https://docs.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-databases-transact-sql?view=sql-server-2017
# Only a 0 counts; while SQL Server is starting, sqlcmd prints its connection error instead, on a
# first boot of a busy machine for longer than a minute.

DBSTATUS=
i=0

while [ $i -lt 120 ]; do
   i=$(expr $i + 1)
   DBSTATUS=$(sqlcmd -C -h -1 -t 5 -b -U sa -P $SA_PASSWORD -Q "SET NOCOUNT ON; Select SUM(state) from sys.databases" 2>/dev/null | tr -d '[:space:]')
   [ "$DBSTATUS" = "0" ] && break
   echo "********** Waiting for the database to start"
   sleep 5
done

if [ "$DBSTATUS" != "0" ]; then
   echo "********** SQL Server took more than 10 minutes to start up or one or more databases are not in an ONLINE state"
   exit 1
fi

# create the certdb database, which Essbase keeps its repository in, unless an earlier start did.
CERTDB=$(sqlcmd -C -h -1 -t 5 -b -U sa -P $SA_PASSWORD -Q "SET NOCOUNT ON; SELECT COUNT(*) FROM sys.databases WHERE name = 'CertDB'" 2>/dev/null | tr -d '[:space:]')
if [ "$CERTDB" != "1" ]; then
   sqlcmd -C -S localhost -b -U sa -P ${SA_PASSWORD} -d master -i ${SCRIPT_DIR}/setup.sql ||
      echo "********** Could not create the CertDB database; Essbase cannot start without it"
fi

# Create the samplebasic database, then serve it as a read-only MCP server (the Essbase GL MCP) on
# port 5000 through Data API builder. DAB starts only after the script, since the script drops and
# recreates the database. The DAB release is downloaded on first use and cached in dab/cache.
# Opt-in per stack: set ENABLE_ESSBASE_GL_MCP=TRUE on the database service.
(
   sqlcmd -C -S localhost -U sa -P ${SA_PASSWORD} -d master -i ${SCRIPT_DIR}/create.samplebasic.database.sqlserver.sql
   if [ "${ENABLE_ESSBASE_GL_MCP^^}" = "TRUE" ]; then
      export DAB_VERSION="${DAB_VERSION:-2.0.12}"
      export DAB_SHA256="${DAB_SHA256:-33108e3ea307fa90605b81c1e5da7f67550de5f29e2a6375a6c41d78f91c65ab}"
      export DAB_HOME="${SCRIPT_DIR}/dab/cache/${DAB_VERSION}"
      export DAB_DATABASE=SampleBasic
      export DAB_PORT=5000
      ${SCRIPT_DIR}/dab/start-dab.sh
   fi
) &

# Unlock the built-in Essbase MCP server (Essbase 26+) once Essbase has initialized its registry.
# Wait for the registry checksum row, not just the table: the registry derives feature flags
# (ENCRYPTION_AT_REST, MEMBER_ON_THE_FLY, AI_*) from OCI=TRUE when it first populates, and only
# recomputes them when its bundled entries file changes. Inserting after that first pass keeps
# those features off; the MCP gate reads OCI lazily and never caches a miss, so no restart is needed.
# Opt-in per stack: set ENABLE_ESSBASE_MCP=TRUE on the database service.
if [ "${ENABLE_ESSBASE_MCP^^}" = "TRUE" ]; then
   (
      i=0
      while [ $i -lt 360 ]; do
         i=$(expr $i + 1)
         FOUND=$(sqlcmd -C -h -1 -t 5 -U sa -P $SA_PASSWORD -d CertDB -Q "SET NOCOUNT ON; SELECT COUNT(*) FROM ESS1_ESSBASE.ESSBASE_PROPERTIES WHERE TYPE = 2" 2>/dev/null | tr -d '[:space:]')
         if [ "${FOUND:-0}" = "1" ]; then
            echo "********** Essbase registry initialized; enabling the built-in Essbase MCP server"
            sqlcmd -C -S localhost -U sa -P ${SA_PASSWORD} -d CertDB -i ${SCRIPT_DIR}/enable-mcp.sql
            exit 0
         fi
         sleep 10
      done
      echo "********** Essbase schema not found after 60 minutes; built-in Essbase MCP server not enabled"
   ) &
fi
