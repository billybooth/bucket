#!/usr/bin/env bash

# Loads what is dropped into the imports folder (.volumes/essbase/imports on the host) into this Essbase server, then
# keeps watching the folder and loads new or changed drops. Each subfolder is the application its files load into,
# whatever names the files carry inside:
#
#   imports/<App>/<Any>.zip      LCM export of one application (21+), imported as <App>
#   imports/<Any>.zip            LCM export of several applications (21+), each under its own name
#   imports/<App>/<Cube>.xlsx    DBX application workbook (21+), imported as <App>.<Cube>; a .zip of the same name
#                                beside it holds the workbook's separate data
#   imports/<App>/<Cube>.otl     outline; ASO or BSO and the Unicode mode are read from the file
#   imports/<App>/<Cube>.txt     data export (<Cube>_2.txt and so on for a split export), loaded after the outline
#
# A drop replaces the cube it names. When anything in an application's folder changes, the whole folder loads again in
# order: LCM exports, then workbooks, outlines, and data, so outlines and data apply on top of an LCM or workbook
# import. A file loads once it stops changing between two polls. Progress goes to ~/imports.log.
#
# A cube is recorded as built from its source only when every step of its build succeeds, so a source with no record,
# a changed source, or a failed build all build again. A failed build is tried again a minute later, up to three times
# in all; after that it waits for its files to change. A build first logs every session out of its application, since
# Essbase refuses to build dimensions while anyone else has the cube open, and a changed drop is the request for the
# rebuild. A cube built here also gets its Embeddings alias table
# (ai-hints/<App>.<Cube>.alt) and, on a stack with Essbase AI, its AI connection and vectors.

# capture the script directory.
script_dir="$(dirname "$(readlink -f "$0")")"

imports_dir="$script_dir/imports"
hints_dir="$script_dir/ai-hints"
state_file="$HOME/.imports-state"
log_file="$HOME/imports.log"
poll_seconds="${IMPORTS_POLL_SECONDS:-15}"
max_attempts=3
retry_seconds="${IMPORTS_RETRY_SECONDS:-60}"
# the AI connection the ai-gateway setup creates (configure-essbase-ai.py); a stack without it has no Essbase AI.
ai_connection="ess_ai_genai"
# a dropped outline is tried in this application before it replaces a cube; the watcher creates it and deletes it
# again, with a cube of the same name, so that Essbase's errors name the cube. Eight characters at most, for 11.1.2.4.
check_app="ImpCheck"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$log_file"
}

# only one watcher per container, even if the setup script runs again.
exec 9> "$HOME/.imports.lock"
flock --nonblock 9 || exit 0

# if this is a 21+ container...
if [ -d /u01 ]; then
  modern=true
  admin_user="${ADMIN_USERNAME:-admin}"
  admin_password="$ADMIN_PASSWORD"
  maxl_shell=$(find /u01/config/domains -path '*/esstools/bin/startMAXL.sh' 2>/dev/null | head -1)
  app_root="${ARBORPATH:-/u01/data/essbase}/app"
  rest_url="http://localhost:${MANAGED_SERVER_PORT:-9000}/essbase/rest/v1"
  jar=$(ls /usr/java/*/bin/jar 2>/dev/null | head -1)
# otherwise, if this is an 11.1.2.4 container...
else
  modern=false
  admin_user="${EPM_ADMIN:-admin}"
  admin_password="$EPM_PASSWORD"
  essbase_instance="$USER_PROJECTS/epmsystem1/EssbaseServer/essbaseserver1"
  maxl_shell="$essbase_instance/bin/startMaxl.sh"
  app_root="$essbase_instance/app"
fi

# runs MaxL statements; the output is left in maxl_output, and the result is false when any statement failed, or when
# the shell did not log in at all (a missing shell prints no Essbase errors).
maxl() {
  local script
  if [ ! -x "$maxl_shell" ]; then
    maxl_output="ERROR - the MaxL shell $maxl_shell is missing."
    return 1
  fi
  script=$(mktemp)
  {
    echo "login \"$admin_user\" \"$admin_password\" on localhost;"
    printf '%s\n' "$@"
    echo "logout;"
  } > "$script"
  maxl_output=$("$maxl_shell" "$script" 2>&1)
  rm -f "$script"
  echo "$maxl_output" | grep -q -E " (1241001|1051034) - " && ! echo "$maxl_output" | grep -q "ERROR - "
}

maxl_errors() {
  if echo "$maxl_output" | grep -q "1042026"; then
    echo "Essbase has no free ports to start another application; unload or delete one and drop the file again."
  else
    echo "$maxl_output" | grep "ERROR - " | sed 's/^ *//' | tr '\n' ' '
  fi
}

rest() {
  curl --silent --user "$admin_user:$admin_password" "$@"
}

# prints a name the files catalog accepts for an upload: it refuses special characters, including a second dot.
upload_name() {
  echo "imports_$(echo "$1" | tr -c 'A-Za-z0-9_\n' '_').$2"
}

# uploads a file to the admin user's folder in the files catalog.
upload() {
  [ "$(rest --output /dev/null --write-out '%{http_code}' -X PUT -H "Content-Type: application/octet-stream" \
    --data-binary @"$1" "$rest_url/files/users/$admin_user/$2?overwrite=true")" = "200" ]
}

remove_upload() {
  rest --output /dev/null -X DELETE "$rest_url/files/users/$admin_user/$1"
}

# runs a REST job and waits up to an hour for it; the result is true when it completed (with or without warnings), and
# job_error holds the server's message otherwise.
run_job() {
  wait_for_job "$(rest -H "Content-Type: application/json" -d "$1" "$rest_url/jobs")"
}

# waits up to an hour for the job a REST reply started; job_status holds how it ended, and the result is as run_job's.
wait_for_job() {
  local reply="$1" id status i
  job_status=""
  # the jobs route gives the id as a number; the vectorize route gives it as a string.
  id=$(echo "$reply" | grep -o '"job_ID" *: *"\?[0-9]*' | grep -o '[0-9]*$')
  if [ -z "$id" ]; then
    job_error="$reply"
    return 1
  fi
  for i in $(seq 1 720); do
    reply=$(rest "$rest_url/jobs/$id")
    status=$(echo "$reply" | grep -o '"statusMessage" *: *"[^"]*"' | head -1 | sed 's/.*: *"//; s/"$//')
    case "$status" in
      "In Progress"|"Not Started"|"") sleep 5 ;;
      *) break ;;
    esac
  done
  job_error=$(echo "$reply" | grep -o '"errorMessage" *: *"\([^"\\]\|\\.\)*' | head -1 |
    sed 's/^"errorMessage" *: *"//; s/\\n$//; s/\\"/"/g')
  job_status="$status"
  case "$status" in
    Completed|"Completed with warnings") return 0 ;;
  esac
  return 1
}

# prints the warnings of the last job that completed with them, for the end of a log line.
job_warnings() {
  [ "$job_status" = "Completed with warnings" ] && [ -n "$job_error" ] && echo " Essbase warned: $job_error"
}

# prints aso, bso-unicode, or bso-native for an outline file. Block storage outlines start with "ABDV1" and carry
# 01 (native) or 02 (Unicode) in their seventh byte; aggregate storage outlines use the paged format instead.
outline_kind() {
  local header
  header=$(head -c 7 "$1" | od -A n -t x1 | tr -d ' \n')
  case "$header" in
    4142445631??02) echo bso-unicode ;;
    4142445631*) echo bso-native ;;
    *) echo aso ;;
  esac
}

# prints the path of a cube's outline on the server, or nothing when the cube has none yet. 26.1 keeps block storage
# outlines in a cube/ subfolder.
server_outline() {
  local path
  for path in "$app_root/$1/$2/cube/$2.otl" "$app_root/$1/$2/$2.otl"; do
    if [ -f "$path" ]; then
      echo "$path"
      return
    fi
  done
}

# prints the kind of an application already on the server, read from any of its outlines.
server_app_kind() {
  local path
  path=$(find "$app_root/$1" -maxdepth 3 -name '*.otl' 2>/dev/null | head -1)
  [ -n "$path" ] && outline_kind "$path"
}

# tells whether Essbase can load an outline file and finds dimensions in it, by loading it into an application of its
# own; the cube it would replace is not touched. Essbase loads a truncated outline as an empty one, which only the
# dimension query refuses. maxl_output holds Essbase's errors when it cannot.
try_outline() {
  local cube="$1" file="$2" kind="$3" result=0 output
  [ -d "$app_root/$check_app" ] && maxl "drop application \"$check_app\" cascade force;"
  case "$kind" in
    aso) maxl "create application \"$check_app\" using aggregate_storage;" ;;
    bso-unicode) maxl "create application \"$check_app\" type unicode_mode;" ;;
    bso-native) maxl "create application \"$check_app\" type nonunicode_mode;" ;;
  esac &&
    maxl "create database \"$check_app\".\"$cube\";" &&
    maxl "alter system unload application \"$check_app\";" &&
    cp "$file" "$(server_outline "$check_app" "$cube")" &&
    maxl "alter system load application \"$check_app\";" &&
    maxl "query database \"$check_app\".\"$cube\" get dbstats dimension;" || result=1
  output="$maxl_output"
  maxl "drop application \"$check_app\" cascade force;"
  maxl_output="$output"
  return $result
}

# puts back the outline a failed drop replaced, so that the cube loads again; its data was cleared already.
restore_outline() {
  local app="$1" cube="$2" target="$3"
  if mv -f "$target.imports-backup" "$target" && maxl "alter system load application \"$app\";"; then
    log "Put the previous outline of $app.$cube back; its data was cleared."
  else
    log "Could not put the previous outline of $app.$cube back: $(maxl_errors)"
  fi
}

load_outline() {
  local app="$1" cube="$2" file="$3" kind app_kind target created=
  kind=$(outline_kind "$file")
  app_kind=$(server_app_kind "$app")

  # an outline Essbase cannot load would leave the cube it replaces without one it can load, so it is tried first.
  if ! try_outline "$cube" "$file" "$kind"; then
    log "Skipped $app/$cube.otl, which Essbase cannot load; $app.$cube was not changed. $(maxl_errors)"
    return 1
  fi

  if [ -d "$app_root/$app" ] && [ -n "$app_kind" ] && [ "${app_kind%%-*}" != "${kind%%-*}" ]; then
    log "Skipped $app/$cube.otl: it is a ${kind%%-*} outline, and application $app is ${app_kind%%-*}."
    return 1
  fi

  if [ ! -d "$app_root/$app" ]; then
    case "$kind" in
      aso) maxl "create application \"$app\" using aggregate_storage;" ;;
      bso-unicode) maxl "create application \"$app\" type unicode_mode;" ;;
      bso-native) maxl "create application \"$app\" type nonunicode_mode;" ;;
    esac || { log "Could not create application $app: $(maxl_errors)"; return 1; }
    created=application
  fi

  if [ -z "$(server_outline "$app" "$cube")" ]; then
    maxl "create database \"$app\".\"$cube\";" || { log "Could not create cube $app.$cube: $(maxl_errors)"; return 1; }
    [ -z "$created" ] && created=cube
  else
    # clear the cube's data, which would not fit the new outline.
    logout_sessions "$app"
    if [ "$kind" = aso ]; then
      maxl "alter database \"$app\".\"$cube\" reset all;"
    else
      maxl "alter database \"$app\".\"$cube\" reset;"
    fi || if echo "$maxl_output" | grep -q -E "1013003|\[1250012\]"; then
      # the cube's own outline is empty or does not load, so neither does its data; the cube is created again.
      log "$app.$cube does not load its outline, so it is created again for $cube.otl."
      maxl "drop database \"$app\".\"$cube\" force;" && maxl "create database \"$app\".\"$cube\";" ||
        { log "Could not create cube $app.$cube again: $(maxl_errors)"; return 1; }
      created=cube
    else
      log "Could not clear the data of $app.$cube: $(maxl_errors)"
      return 1
    fi
  fi

  logout_sessions "$app"
  # 1054004: the application is not loaded, which is all the unload is for.
  maxl "alter system unload application \"$app\";" || echo "$maxl_output" | grep -q 1054004 ||
    { log "Could not unload application $app to replace the outline of $cube: $(maxl_errors)"; return 1; }
  if [ "$app_kind" = bso-native ] && [ "$kind" = bso-unicode ]; then
    maxl "alter application \"$app\" set type unicode_mode;" ||
      { log "Could not convert application $app to Unicode for $cube.otl: $(maxl_errors)"; return 1; }
  fi

  target=$(server_outline "$app" "$cube")
  if ! cp -f "$target" "$target.imports-backup" || ! cp "$file" "$target"; then
    log "Could not copy $cube.otl into application $app."
    rm -f "$target.imports-backup"
    maxl "alter system load application \"$app\";"
    return 1
  fi
  rm -f "$target.keep"
  if maxl "alter system load application \"$app\";"; then
    rm -f "$target.imports-backup"
    log "Loaded the outline of $app.$cube ($kind)."
    return 0
  fi

  # the outline loaded on its own but not here; a cube or application this drop created goes again, and a cube that
  # was there gets its previous outline back.
  log "Could not load the outline of $app.$cube: $(maxl_errors)"
  case "$created" in
    application) maxl "drop application \"$app\" cascade force;" ;;
    cube) maxl "drop database \"$app\".\"$cube\" force;" ;;
    *) restore_outline "$app" "$cube" "$target" ;;
  esac
  return 1
}

# loads Essbase data exports into a cube, then calculates a block storage cube, since a level 0 export holds no totals.
# The result is false when Essbase refused a load or the calculation; a file skipped for what it holds is not a failure.
load_data() {
  local app="$1" cube="$2" outline file name cells loaded=false failed=false
  shift 2
  outline=$(server_outline "$app" "$cube")
  if [ -z "$outline" ]; then
    log "Skipped the data for $app.$cube: the cube does not exist; drop its outline, workbook, or LCM export too."
    return 1
  fi
  for file in "$@"; do
    name="imports.$(basename "$file")"
    # a Unicode export starts with a UTF-8 marker, which a non-Unicode cube refuses; plain ASCII text loads without it.
    if [ "$(outline_kind "$outline")" = bso-native ] && [ "$(head -c 3 "$file" | od -A n -t x1 | tr -d ' ')" = efbbbf ]; then
      if [ "$(tail -c +4 "$file" | LC_ALL=C tr -d '\000-\177' | head -c 1 | wc -c)" -ne 0 ]; then
        log "Skipped $(basename "$file"): it is a Unicode export with non-ASCII text, and $app.$cube is not Unicode."
        continue
      fi
      tail -c +4 "$file" > "$app_root/$app/$cube/$name"
    else
      cp "$file" "$app_root/$app/$cube/$name"
    fi
    if maxl "import database \"$app\".\"$cube\" data from server data_file \"$name\" on error abort;"; then
      cells=$(echo "$maxl_output" | grep -io 'updated *\[[0-9]*\] cells' | head -1 | grep -o '[0-9]*')
      log "Loaded $(basename "$file") into $app.$cube${cells:+ ($cells cells updated)}."
      loaded=true
    else
      log "Could not load $(basename "$file") into $app.$cube: $(maxl_errors)"
      failed=true
    fi
    rm -f "$app_root/$app/$cube/$name"
  done
  if $loaded; then
    calculate "$app" "$cube" || failed=true
  fi
  ! $failed
}

# runs the default calculation of a block storage cube, so its loaded level 0 data rolls up; aggregate storage cubes
# need none.
calculate() {
  [ "$(outline_kind "$(server_outline "$1" "$2")")" != aso ] || return 0
  if maxl "execute calculation default on \"$1\".\"$2\";"; then
    log "Calculated $1.$2."
  else
    log "Could not calculate $1.$2: $(maxl_errors)"
    return 1
  fi
}

# deletes a cube a workbook replaces; Essbase refuses while the cube is busy, so this unloads the application and
# tries again once.
delete_cube() {
  [ -n "$(server_outline "$1" "$2")" ] || return 0
  logout_sessions "$1"
  [ "$(rest --output /dev/null --write-out '%{http_code}' -X DELETE "$rest_url/applications/$1/databases/$2")" = 204 ] &&
    return 0
  maxl "alter system unload application \"$1\";"
  [ "$(rest --output /dev/null --write-out '%{http_code}' -X DELETE "$rest_url/applications/$1/databases/$2")" = 204 ] &&
    return 0
  log "Could not delete $1.$2 to replace it with $2.xlsx."
  return 1
}

import_workbook() {
  run_job "{\"jobtype\":\"importExcel\",\"application\":\"$1\",\"db\":\"$2\",\"parameters\":{
    \"catalogExcelPath\":\"/users/$admin_user/$3\",\"importExcelFileName\":\"$3\",\"loaddata\":\"$4\",
    \"recreateApplication\":\"false\",\"createFiles\":\"true\",\"executeScript\":\"false\",\"buildOption\":\"NONE\"}}"
}

load_workbook() {
  local app="$1" cube="$2" file="$3" data_zip="$4" name extract_dir imported=false with_data=false
  name=$(upload_name "${app}_$cube" xlsx)
  delete_cube "$app" "$cube" || return 1
  upload "$file" "$name" || { log "Could not upload $app/$cube.xlsx."; return 1; }
  # a workbook whose data comes in a separate zip has none of its own, and asking for it fails the import.
  if [ -n "$data_zip" ]; then
    import_workbook "$app" "$cube" "$name" false && imported=true
  elif import_workbook "$app" "$cube" "$name" true; then
    imported=true
    with_data=true
    # a workbook without data of its own imports with this warning, and has nothing to calculate.
    if echo "$job_error" | grep -q "Data source details not found"; then
      with_data=false
      job_status=""
    fi
  elif echo "$job_error" | grep -q "Data source details not found"; then
    delete_cube "$app" "$cube" && import_workbook "$app" "$cube" "$name" false && imported=true
  fi
  if $imported; then
    log "Imported the workbook $cube.xlsx as $app.$cube.$(job_warnings)"
  else
    log "Could not import the workbook $cube.xlsx as $app.$cube: $job_error"
    remove_upload "$name"
    return 1
  fi
  remove_upload "$name"

  if [ -n "$data_zip" ]; then
    local result=0
    if [ -z "$jar" ]; then
      log "Could not read $cube.zip: this Essbase image has no jar tool to open zips."
      return 1
    fi
    extract_dir=$(mktemp -d)
    (cd "$extract_dir" && "$jar" xf "$data_zip")
    load_data "$app" "$cube" $(find "$extract_dir" -type f | sort) || result=1
    rm -rf "$extract_dir"
    return $result
  elif $with_data; then
    calculate "$app" "$cube"
  fi
}

# logs every session out of an application on the server before a build replaces its cubes.
logout_sessions() {
  local count
  if maxl "alter system logout session on application '$1' force;"; then
    count=$(echo "$maxl_output" | grep -o 'Sessions logged out \[[0-9]*\]' | grep -o '[0-9]*')
    if [ "${count:-0}" -eq 1 ]; then
      log "Logged 1 session out of $1."
    elif [ "${count:-0}" -gt 1 ]; then
      log "Logged $count sessions out of $1."
    fi
  elif ! echo "$maxl_output" | grep -q "1051030"; then
    log "Could not log the sessions out of $1: $(maxl_errors)"
  fi
  return 0
}

# prints the applications an LCM export holds (the top folders that contain Databases/), one per line.
lcm_applications() {
  "$jar" tf "$1" 2>/dev/null | grep -o '^[^/]*/Databases/' | cut -d/ -f1 | sort -u
}

load_lcm() {
  local file="$1" target="$2" name parameters source
  name=$(upload_name "$(basename "${file%.*}")" zip)
  source=$(lcm_applications "$file" | tr '\n' ' ')
  parameters="\"zipFileName\":\"$name\",\"overwrite\":\"true\""
  [ -n "$target" ] && parameters="$parameters,\"targetApplicationName\":\"$target\""
  upload "$file" "$name" || { log "Could not upload $(basename "$file")."; return 1; }
  if run_job "{\"jobtype\":\"lcmImport\",\"parameters\":{$parameters}}"; then
    if [ -n "$target" ]; then
      log "Imported the LCM export of ${source% } as $target.$(job_warnings)"
    else
      log "Imported the LCM export of ${source% }.$(job_warnings)"
    fi
  else
    log "Could not import the LCM export $(basename "$file"): $job_error"
    remove_upload "$name"
    return 1
  fi
  remove_upload "$name"
}

# loads one application's folder in order: LCM exports, workbooks, outlines, then data.
load_application() {
  local app="$1" folder="$imports_dir/$1" file name cube base apps
  local -a lcm_files=() workbooks=() outlines=()
  local -A data_files=()
  local unreadable=false

  logout_sessions "$app"
  for file in "$folder"/*; do
    [ -f "$file" ] && ! ignored "$file" || continue
    name=$(basename "$file")
    case "${name,,}" in
      *.otl) outlines+=("$file") ;;
      *.xlsx) workbooks+=("$file") ;;
      *.txt)
        base="${name%.*}"
        cube="$base"
        # a split export's later files end in _2, _3, and so on.
        if [[ "$base" =~ ^(.+)_[0-9]+$ ]] && [ ! -f "$folder/$base.otl" ] && [ ! -f "$folder/$base.xlsx" ] &&
          [ -z "$(server_outline "$app" "$base")" ]; then
          cube="${BASH_REMATCH[1]}"
        fi
        data_files[$cube]="${data_files[$cube]}$file"$'\n'
        ;;
      *.zip)
        # a zip with a workbook of the same name holds that workbook's data.
        [ -f "${file%.*}.xlsx" ] && continue
        if ! $modern; then
          log "Skipped $app/$name: Essbase 11.1.2.4 takes outlines and data exports only."
          continue
        fi
        if [ -z "$jar" ]; then
          log "Could not read $app/$name: this Essbase image has no jar tool to open zips."
          unreadable=true
          continue
        fi
        apps=$(lcm_applications "$file" | wc -l)
        if [ "$apps" -eq 1 ]; then
          lcm_files+=("$file")
        elif [ "$apps" -gt 1 ]; then
          log "Skipped $app/$name: it holds several applications; move it to the top of the imports folder."
        else
          log "Skipped $app/$name: it is not an LCM export, and no workbook named ${name%.*}.xlsx is beside it."
        fi
        ;;
      *.pag|*.ind|*.dat|*.esm|*.tct|*.db|*.dbb)
        log "Skipped $app/$name: storage files do not move between servers; ask for a data export (.txt) instead."
        ;;
      *) log "Skipped $app/$name: not an outline, workbook, LCM export, or data export." ;;
    esac
  done

  if ! $modern && [ ${#workbooks[@]} -gt 0 ]; then
    log "Skipped the workbooks in $app: Essbase 11.1.2.4 takes outlines and data exports only."
    workbooks=()
  fi

  local result=0
  $unreadable && result=1
  for file in "${lcm_files[@]}"; do
    load_lcm "$file" "$app" || result=1
  done
  for file in "${workbooks[@]}"; do
    name=$(basename "$file")
    if [ -f "${file%.*}.zip" ]; then
      load_workbook "$app" "${name%.*}" "$file" "${file%.*}.zip" || result=1
    else
      load_workbook "$app" "${name%.*}" "$file" || result=1
    fi
  done
  # a cube whose outline did not load keeps its previous outline, which the new data may not fit.
  local -A outline_failed=()
  for file in "${outlines[@]}"; do
    name=$(basename "$file")
    load_outline "$app" "${name%.*}" "$file" || { result=1; outline_failed[${name%.*}]=1; }
  done
  for cube in "${!data_files[@]}"; do
    if [ -n "${outline_failed[$cube]}" ]; then
      log "Skipped the data for $app.$cube: its outline did not load."
      continue
    fi
    local -a files=()
    while IFS= read -r file; do
      [ -n "$file" ] && files+=("$file")
    done <<< "$(printf '%s' "${data_files[$cube]}" | sort)"
    load_data "$app" "$cube" "${files[@]}" || result=1
  done

  # 11.1.2.4 has few ports for running applications; Essbase starts an application again when it is next used.
  if ! $modern && [ -d "$app_root/$app" ]; then
    maxl "alter system unload application \"$app\";"
  fi
  return $result
}

# prints the cubes of an application on the server, one per line.
server_cubes() {
  local cube
  for cube in "$app_root/$1"/*/; do
    cube=$(basename "$cube")
    [ -n "$(server_outline "$1" "$cube")" ] && echo "$cube"
  done
}

# loads a cube's Embeddings alias table from ai-hints/<App>.<Cube>.alt, when the stack has one for it. MaxL loads alias
# tables only from the cube's own folder, so the file goes there first.
load_alias_table() {
  local app="$1" cube="$2" file="$hints_dir/$1.$2.alt"
  [ -f "$file" ] || return 0
  cp "$file" "$app_root/$app/$cube/embeddings.alt" || { log "Could not copy $app.$cube.alt into the cube."; return 1; }
  maxl "alter database \"$app\".\"$cube\" unload alias_table \"Embeddings\";"
  if maxl "alter database \"$app\".\"$cube\" load alias_table \"Embeddings\" from data_file \"embeddings.alt\";"; then
    log "Loaded the Embeddings alias table of $app.$cube."
  else
    log "Could not load the Embeddings alias table of $app.$cube: $(maxl_errors)"
  fi
  rm -f "$app_root/$app/$cube/embeddings.alt"
}

# gives a cube Essbase AI on a stack that has it: associates its application with the stack's AI connection, and
# vectorizes the cube's outline, which a rebuilt cube needs again. An application this associated is released again
# when its cube cannot be vectorized, so that the ai-gateway setup takes it for unfinished and tries again.
enable_ai() {
  local app="$1" cube="$2" associated=false
  $modern || return 0
  [ "$(rest --output /dev/null --write-out '%{http_code}' "$rest_url/connections/$ai_connection")" = 200 ] || return 0
  if ! rest "$rest_url/ai/connection?application=$app" | grep -q "$ai_connection"; then
    if [ "$(rest --output /dev/null --write-out '%{http_code}' -X POST -H "Content-Type: application/json" \
      "$rest_url/ai/applications/$app/connection/$ai_connection")" != 200 ]; then
      log "Could not give $app the AI connection $ai_connection."
      return 1
    fi
    associated=true
  fi
  wait_for_job "$(rest -X POST -H "Content-Type: application/json" \
    "$rest_url/ai/applications/$app/job/vectorize/databases/$cube")"
  # a vectorize job may also end "Completed with warnings".
  if [[ "$job_status" == Completed* ]]; then
    log "Vectorized $app.$cube for Essbase AI."
  else
    log "Could not vectorize $app.$cube for Essbase AI: ${job_error:-$job_status}"
    $associated && rest --output /dev/null -X DELETE "$rest_url/ai/applications/$app/connection"
    return 1
  fi
}

# brings in what a built cube needs beyond its own files. A failure here is logged, and does not make the build fail,
# since building the cube again would not help.
finish_cube() {
  load_alias_table "$1" "$2"
  enable_ai "$1" "$2"
  return 0
}

finish_application() {
  local cube
  for cube in $(server_cubes "$1"); do
    finish_cube "$1" "$cube"
  done
}

# tells whether a file is one a program keeps beside the files it has open (Excel's ~$Basic.xlsx while Basic.xlsx is
# open), or one a folder view writes; such files are never drops.
ignored() {
  local name="${1##*/}"
  case "${name,,}" in
    '~$'*|.~lock.*|*.tmp|*.crdownload|*.part|desktop.ini|thumbs.db|.ds_store|._*) return 0 ;;
  esac
  return 1
}

# a file's signature changes whenever it is written.
signature() {
  stat -c '%s.%Y' "$1" 2>/dev/null
}

# the signature of everything in an application's folder.
folder_signature() {
  local file
  for file in "$imports_dir/$1"/*; do
    [ -f "$file" ] && ! ignored "$file" && echo "${file#$imports_dir/}|$(signature "$file")"
  done | sort | md5sum | cut -c1-32
}

# Failed builds: how many times each source (an application or a top-level zip) has failed, when to
# try it again, and the signature of the source that failed, so that a changed source starts its attempts afresh.
declare -A attempts=() retry_at=() failed_signature=()

# tells whether a build of a source with this signature may run now.
due() {
  if [ "${failed_signature[$1]}" != "$2" ]; then
    unset "attempts[$1]" "retry_at[$1]" "failed_signature[$1]"
    return 0
  fi
  [ "${attempts[$1]:-0}" -lt "$max_attempts" ] && [ "$(date +%s)" -ge "${retry_at[$1]:-0}" ]
}

# records a failed build of a source with this signature.
failed() {
  failed_signature[$1]="$2"
  attempts[$1]=$(( ${attempts[$1]:-0} + 1 ))
  retry_at[$1]=$(( $(date +%s) + retry_seconds ))
  if [ "${attempts[$1]}" -ge "$max_attempts" ]; then
    log "Stopped trying $1 after $max_attempts failed attempts; it builds again when its source changes."
  else
    log "Will try $1 again in $retry_seconds seconds."
  fi
}

declare -A seen=() loaded=()
if [ -f "$state_file" ]; then
  while IFS='|' read -r path sig; do
    [ -n "$path" ] && loaded[$path]="$sig"
  done < "$state_file"
fi

save_state() {
  local path
  for path in "${!loaded[@]}"; do
    echo "$path|${loaded[$path]}"
  done > "$state_file"
}

# wait for Essbase to accept a login; 11.1.2.4 also finishes loading its sample cubes first.
[ -x "$maxl_shell" ] || log "Waiting for the MaxL shell ($maxl_shell); nothing loads without it."
until maxl; do
  sleep 30
done
$modern && [ -z "$jar" ] && log "This Essbase image has no jar tool, so LCM exports and workbook data zips cannot load."
if ! $modern; then
  until [ -f "$HOME/.hasBeenConfigured" ]; do
    sleep 30
  done
fi
log "Watching $imports_dir every $poll_seconds seconds."

while :; do
  if [ -d "$imports_dir" ]; then
    changed_apps=()
    changed_zips=()
    pending=false

    for file in "$imports_dir"/*.zip "$imports_dir"/*/*; do
      [ -f "$file" ] && ! ignored "$file" || continue
      path="${file#$imports_dir/}"
      sig=$(signature "$file")
      [ "${loaded[$path]}" = "$sig" ] && continue
      # wait until the file stops changing, so a copy in progress is not loaded.
      if [ "${seen[$path]}" != "$sig" ]; then
        seen[$path]="$sig"
        pending=true
        continue
      fi
      case "$path" in
        */*) changed_apps+=("${path%%/*}") ;;
        *) changed_zips+=("$file") ;;
      esac
    done

    # forget files that were removed, so the same files dropped in again load again.
    pruned=false
    for path in "${!loaded[@]}"; do
      [ -f "$imports_dir/$path" ] && continue
      unset "loaded[$path]"
      pruned=true
    done
    $pruned && save_state

    # load an application's folder only when every file in it is settled. Its files are recorded only when it loads.
    if ! $pending; then
      for file in "${changed_zips[@]}"; do
        path="${file#$imports_dir/}"
        sig=$(signature "$file")
        due "$path" "$sig" || continue
        if ! $modern; then
          log "Skipped $(basename "$file"): Essbase 11.1.2.4 takes outlines and data exports only."
        elif [ -z "$jar" ]; then
          log "Could not read $(basename "$file"): this Essbase image has no jar tool to open zips."
          failed "$path" "$sig"
          continue
        elif [ "$(lcm_applications "$file" | wc -l)" -gt 0 ]; then
          for app in $(lcm_applications "$file"); do
            logout_sessions "$app"
          done
          if ! load_lcm "$file"; then
            failed "$path" "$sig"
            continue
          fi
          for app in $(lcm_applications "$file"); do
            finish_application "$app"
          done
        else
          log "Skipped $(basename "$file"): only LCM exports go at the top of the imports folder."
        fi
        loaded[$path]="$sig"
        save_state
      done
      for app in $(printf '%s\n' "${changed_apps[@]}" | sort -u); do
        sig=$(folder_signature "$app")
        due "$app" "$sig" || continue
        # the files as they are when the load starts, so that a file changed during the load loads again.
        file_signatures=()
        for file in "$imports_dir/$app"/*; do
          [ -f "$file" ] && ! ignored "$file" && file_signatures+=("${file#$imports_dir/}|$(signature "$file")")
        done
        if ! load_application "$app"; then
          failed "$app" "$sig"
          continue
        fi
        for entry in "${file_signatures[@]}"; do
          loaded[${entry%|*}]="${entry##*|}"
        done
        save_state
        finish_application "$app"
      done
    fi
  fi
  [ -n "$IMPORTS_ONCE" ] && ! $pending && break
  # the sleep must not inherit the lock, or a watcher started right after this one stops would find it still held.
  sleep "$poll_seconds" 9>&-
done
