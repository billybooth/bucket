#!/usr/bin/env bash

# capture the script directory.
script_dir="$(dirname "$(readlink -f "$0")")"

# if this is a 21+ container...
if [ -d /u01 ]; then
  # add -Dcom.sun.jndi.ldapURLParsing=LEGACY to JAVA_OPTIONS as workaround for:
  # BUG 34274274 - JDK 1.8 331 UPGRADE CAUSES SECURE LDAP LINKS FAIL
  #if [ -e "/u01/config/domains/infra_domain/bin/setStartupEnv.sh" ]; then
  #  if [[ -s "/u01/config/domains/infra_domain/bin/setStartupEnv.sh" && -z "$(tail -c 1 "/u01/config/domains/infra_domain/bin/setStartupEnv.sh")" ]]; then
  #    echo "JAVA_OPTIONS=\"\${JAVA_OPTIONS} -Dcom.sun.jndi.ldapURLParsing=LEGACY\"" >> "/u01/config/domains/infra_domain/bin/setStartupEnv.sh"
  #    echo "export JAVA_OPTIONS" >> "/u01/config/domains/infra_domain/bin/setStartupEnv.sh"
  #  fi
  #fi
  
  # run the setup script in the background.
  if [ -e "$script_dir/waitForAndSetUpEnvironment.sh" ]; then
    echo "starting wait script in background..." >> ~/wrapper.log
    nohup "$script_dir/waitForAndSetUpEnvironment.sh" &
  fi
  
  # Identity Cloud mode (IDENTITY_PROVIDER=IDCS, "essbase identity idcs"): the domain must trust the OCI gateway, whose
  # certificate authority the gateway issues when it first starts. At creation the trust is added right after the image's
  # own IDCS step, before the servers first start; later starts find it in place (trustOciGateway.sh).
  if [ "${IDENTITY_PROVIDER^^}" = "IDCS" ] && [ -e "$script_dir/trustOciGateway.sh" ]; then
    for _ in $(seq 1 150); do [ -s /opt/oci-certs/ca.crt ] && break; sleep 2; done
    # The image's IDCS step also sets LOGOUT_URL, which makes the web UI redirect its login page to Oracle's Cloud Gate
    # front door; this stack has none, so the property is dropped and the UI keeps its sign-in form (WebLogic checks the
    # form's credentials the same way as basic authentication: embedded admin, or a gateway user).
    sed -i "/dictionary\['LOGOUT_URL'\] = logoutUrl/d" "$script_dir/wlst/enable_idcs_mode.py"
    if ! grep -q trustOciGateway.sh "$script_dir/_createDomain.sh"; then
      awk '{ print } /enable_idcs_mode.py/ { pending = 1 } pending && /^EOF$/ { print "  \"${SCRIPT_DIR}/trustOciGateway.sh\""; pending = 0 }' "$script_dir/_createDomain.sh" > "$script_dir/_createDomain.sh.oci" && cat "$script_dir/_createDomain.sh.oci" > "$script_dir/_createDomain.sh" && rm -f "$script_dir/_createDomain.sh.oci"
    fi
    "$script_dir/trustOciGateway.sh" >> ~/wrapper.log 2>&1
  fi

  # Essbase's managed server (essbase_server1) gets a 1 GB heap when the image creates the domain, and Essbase refuses to
  # run a drill-through report while less than a tenth of the heap is free, which a 1 GB heap often is on this stack. The
  # heap is raised to ESSBASE_MANAGED_SERVER_HEAP (4g unless it is set) in the domain's startup settings: at every start
  # for a domain that exists, and for a new one right after it is created, before its servers first start.
  essbase_heap="${ESSBASE_MANAGED_SERVER_HEAP:-4g}"
  if ! [[ "$essbase_heap" =~ ^[0-9]+[kKmMgG]$ ]]; then
    echo "ESSBASE_MANAGED_SERVER_HEAP=$essbase_heap is not a heap size such as 4g; using 4g" >> ~/wrapper.log
    essbase_heap=4g
  fi
  cat > "$script_dir/setEssbaseHeap.sh" <<HEAP
#!/usr/bin/env bash
# Written by wrapper.sh: sets the heap of Essbase's managed server (the ESSBASE-MAN-SVR startup group) to ${essbase_heap}.
for f in /u01/config/domains/*/bin/setStartupEnv.sh; do
  [ -e "\$f" ] && sed -i -E '/STARTUP_GROUP\}" = "ESSBASE-MAN-SVR"/,/^fi/ s/-Xmx[0-9]+[kKmMgG]?/-Xmx${essbase_heap}/g' "\$f"
done
exit 0
HEAP
  chmod +x "$script_dir/setEssbaseHeap.sh"
  "$script_dir/setEssbaseHeap.sh"
  if ! grep -q setEssbaseHeap.sh "$script_dir/createAndStartDomain.sh"; then
    sed -i '/esstools\/bin\/start\.sh </i "${SCRIPT_DIR}/setEssbaseHeap.sh"' "$script_dir/createAndStartDomain.sh"
  fi

  echo "starting create script in foreground..." >> ~/wrapper.log
  
  # run the standard create and start domain script.
  exec "$script_dir/createAndStartDomain.sh"
# otherwise, if this is an 11.1.2.4 container...
else
  echo "patching configured ports into essbase-config.xml" >> ~/wrapper.log
  # patch configured ports into the essbase-config.xml.
  sed -i \
    -e "s/>7000/>$ADMIN_SERVER_PORT/g" \
    -e "s/>7001/>$ADMIN_SERVER_SSL_PORT/g" \
    -e "s/>9000/>$MANAGED_SERVER_PORT/g" \
    -e "s/>9443/>$MANAGED_SERVER_SSL_PORT/g" \
    "$script_dir/essbase-config.xml"

    # load what is in the imports folder once Essbase is up, and keep watching it (see importWatcher.sh).
    if [ -e "$script_dir/importWatcher.sh" ]; then
      nohup "$script_dir/importWatcher.sh" > /dev/null 2>&1 &
    fi

    echo "starting config and start script in foreground..." >> ~/wrapper.log

    # run the standard config and start script.
    exec "$script_dir/config-and-start.sh"
fi
