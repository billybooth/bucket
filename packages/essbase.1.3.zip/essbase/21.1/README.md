# Essbase 21c on Docker

The Essbase 21c on Docker project is based on Oracle's files. We have an image published to the Applied OLAP Docker with the ID `appliedolap/essbase:21.1.0`. 

Unlike the Essbase images for 11.1.2.4, there are no sample databases automatically loaded with this image type (yet).

## Getting Started

On Linux and Mac you can run the `start_essbase.sh` script to start and configure an Essbase 21c server. On the first run, your system will download the necessary images (the Essbase image itself, as well as Microsoft's SQL Server 2019 image). 

Upon running `start_essbase.sh` you may see ouput similar to the following (this is from a run that was done after an initial one that downloaded the necessary images):

```
(base) Jasons-MBP-2:Essbase21c jasonwjones$ ./start_essbase.sh 
Starting Essbase stack - sample
Docker Compose is now in the Docker CLI, try `docker compose up`

Creating network "sample_oracle_net" with the default driver
Creating sample_database_1 ... done
Creating sample_essbase_1  ... done
Waiting for Essbase service to be available
Pinging http://localhost:9000/weblogic/ready
Essbase service is ready at http://localhost:9000/essbase
```

URLS:

* JET UI: http://localhost:9000/essbase/jet
* Provider Services: http://localhost:9000/essbase/japi
* Swagger documentation: http://localhost:9000/essbase/rest/doc/
* REST API endpoint: http://localhost:9000/essbase/rest/v1

Default username and password: admin / welcome1

## License

These scripts are based on the Oracle Essbase Docker project, which is licensed under the UPL. The UPL can be found here: https://oss.oracle.com/licenses/upl