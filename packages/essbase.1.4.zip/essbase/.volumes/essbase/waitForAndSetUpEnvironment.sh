#!/usr/bin/env bash

# capture the script directory.
script_dir="$(dirname "$(readlink -f "$0")")"

#echo "wait script started at $(date +%r)." >> ~/wrapper.log

# Check if the domain was actually created successfully
domain_marker_success_file=/u01/config/.marker.domain.success

sleep 5

if [ ! -e "$domain_marker_success_file" ]; then
  echo "no domain success marker by $(date +%r); checking every 5 seconds..." >> ~/wrapper.log
fi

while [ ! -e "$domain_marker_success_file" ]; do
  echo -n "." >> ~/wrapper.log
  sleep 5;
done

echo "." >>  ~/wrapper.log
echo "domain created by $(date +%r)." >> ~/wrapper.log

sleep  5

rest_url="http://localhost:$MANAGED_SERVER_PORT/essbase/rest/v1"

if [ ! $(curl --output /dev/null --silent --head --fail --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" "$rest_url/session") ]; then
  echo "no REST service available by $(date +%r); checking every 5 seconds..." >> ~/wrapper.log
fi

until $(curl --output /dev/null --silent --head --fail --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" "$rest_url/session"); do
    echo -n "." >> ~/wrapper.log
    sleep 5
done

echo >> ~/wrapper.log
echo "REST service available by $(date +%r)." >> ~/wrapper.log

sleep 2

echo "Getting session token..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" "$rest_url/session?token=true" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

if [ ! $(curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "accept: application/json" "$rest_url/files/gallery/Applications/Demo Samples/Block Storage" | grep -q Sample_Basic.xlsx) ]; then
  echo "Gallery files not available by $(date +%r); checking every 5 seconds..." >> ~/wrapper.log
fi

until $(curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "accept: application/json" "$rest_url/files/gallery/Applications/Demo Samples/Block Storage" | grep -q Sample_Basic.xlsx); do
  echo -n "." >> ~/wrapper.log
  sleep 5
done

echo >> ~/wrapper.log
echo "Gallery files available for import by $(date +%r)." >> ~/wrapper.log

# import sample basic from the gallery
echo "Importing sample.basic..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/import-sample-basic.json" "$rest_url/jobs" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

# import demo basic from the gallery
echo "Importing demo.basic..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/import-demo-basic.json" "$rest_url/jobs" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

# import asosample basic from the gallery
echo "Importing asosample.basic..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/import-aso-sample.json" "$rest_url/jobs" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 5

if [ $(curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "accept: application/json" "$rest_url/jobs?fullAppName=ASOSamp&systemjobs=false" | grep -q "In Progress") ]; then
  echo "Importing asosample.basic not finished by $(date +%r); checking every 5 seconds..." >> ~/wrapper.log
fi

while $(curl --silent --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "accept: application/json" "$rest_url/jobs?fullAppName=ASOSamp&systemjobs=false" | grep -q "In Progress"); do
  echo -n "." >> ~/wrapper.log
  sleep 5
done

echo >> ~/wrapper.log
echo "Finished importing asosample.basic by $(date +%r)." >> ~/wrapper.log

# dataload asosamp basic from the gallery
echo "Loading data into asosample.basic..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/dataload-aso-sample.json" "$rest_url/jobs" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

# create drillthrough database connection
echo "Creating connection to SampleBasic database..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/create-drillthrough-connection.json" "$rest_url/connections" >> ~/wrapper.log
echo >> ~/wrapper.log

sleep 2

# create drillthrough datasource
echo "Creating datasource for SampleBasic database..." >> ~/wrapper.log
curl --user "$ADMIN_USERNAME:$ADMIN_PASSWORD" -H "Content-Type: application/json" -d @"$script_dir/json/create-drillthrough-datasource.json" "$rest_url/datasources" >> ~/wrapper.log
echo >> ~/wrapper.log

echo "Done" >> ~/wrapper.log
