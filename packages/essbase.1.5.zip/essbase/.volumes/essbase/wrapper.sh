#!/usr/bin/env bash

# capture the script directory.
script_dir="$(dirname "$(readlink -f "$0")")"

# run the setup script in the background.
if [ -e "$script_dir/waitForAndSetUpEnvironment.sh" ]; then
  echo "starting wait script in background..." >> ~/wrapper.log
  nohup "$script_dir/waitForAndSetUpEnvironment.sh" &
fi

echo "starting create script in foreground..." >> ~/wrapper.log

# run the standard create and start domain script.
exec "$script_dir/createAndStartDomain.sh"
