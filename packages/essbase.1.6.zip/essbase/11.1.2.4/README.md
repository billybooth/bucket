
## Getting Started

Run the `start_essbase.cmd` script to start and configure an Essbase 11.1.2.4 server. On the first run, your system will download the necessary images (the Essbase image itself, as well as Microsoft's SQL Server 2017 image). 


URLS:
* Provider Services: http://localhost:11000/essbase/japi

Default username and password: admin / password1

## License

These scripts are based on the Oracle Essbase Docker project, which is licensed under the UPL. The UPL can be found here: https://oss.oracle.com/licenses/upl