#!/usr/bin/env bash

# capture the script directory.
script_dir="$(dirname "$(readlink -f "$0")")"

# add -Dcom.sun.jndi.ldapURLParsing=LEGACY to JAVA_OPTIONS as workaround for:
# BUG 34274274 - JDK 1.8 331 UPGRADE CAUSES SECURE LDAP LINKS FAIL
#if [ -e "/u01/config/domains/infra_domain/bin/setStartupEnv.sh" ]; then
#  if [[ -s "/u01/config/domains/infra_domain/bin/setStartupEnv.sh" && -z "$(tail -c 1 "/u01/config/domains/infra_domain/bin/setStartupEnv.sh")" ]]; then
#    echo "JAVA_OPTIONS=\"\${JAVA_OPTIONS} -Dcom.sun.jndi.ldapURLParsing=LEGACY\"" >> "/u01/config/domains/infra_domain/bin/setStartupEnv.sh"
#    echo "export JAVA_OPTIONS" >> "/u01/config/domains/infra_domain/bin/setStartupEnv.sh"
#  fi
#fi

# run the setup script in the background.
if [ -e "$script_dir/waitForAndSetUpEnvironment.sh" ]; then
  echo "starting wait script in background..." >> ~/wrapper.log
  nohup "$script_dir/waitForAndSetUpEnvironment.sh" &
fi

echo "starting create script in foreground..." >> ~/wrapper.log

# run the standard create and start domain script.
exec "$script_dir/createAndStartDomain.sh"
