#!/usr/bin/env bash

# capture the script directory.
script_dir="$(dirname "$(readlink -f "$0")")"

# if this is a 21+ container...
if [ -d /u01 ]; then
  # add -Dcom.sun.jndi.ldapURLParsing=LEGACY to JAVA_OPTIONS as workaround for:
  # BUG 34274274 - JDK 1.8 331 UPGRADE CAUSES SECURE LDAP LINKS FAIL
  #if [ -e "/u01/config/domains/infra_domain/bin/setStartupEnv.sh" ]; then
  #  if [[ -s "/u01/config/domains/infra_domain/bin/setStartupEnv.sh" && -z "$(tail -c 1 "/u01/config/domains/infra_domain/bin/setStartupEnv.sh")" ]]; then
  #    echo "JAVA_OPTIONS=\"\${JAVA_OPTIONS} -Dcom.sun.jndi.ldapURLParsing=LEGACY\"" >> "/u01/config/domains/infra_domain/bin/setStartupEnv.sh"
  #    echo "export JAVA_OPTIONS" >> "/u01/config/domains/infra_domain/bin/setStartupEnv.sh"
  #  fi
  #fi
  
  # run the setup script in the background.
  if [ -e "$script_dir/waitForAndSetUpEnvironment.sh" ]; then
    echo "starting wait script in background..." >> ~/wrapper.log
    nohup "$script_dir/waitForAndSetUpEnvironment.sh" &
  fi
  
  echo "starting create script in foreground..." >> ~/wrapper.log
  
  # run the standard create and start domain script.
  exec "$script_dir/createAndStartDomain.sh"
# otherwise, if this is an 11.1.2.4 container...
else
  echo "patching configured ports into essbase-config.xml" >> ~/wrapper.log
  # patch configured ports into the essbase-config.xml.
  sed -i \
    -e "s/>7000/>$ADMIN_SERVER_PORT/g" \
    -e "s/>7001/>$ADMIN_SERVER_SSL_PORT/g" \
    -e "s/>9000/>$MANAGED_SERVER_PORT/g" \
    -e "s/>9443/>$MANAGED_SERVER_SSL_PORT/g" \
    "$script_dir/essbase-config.xml"

    echo "starting config and start script in foreground..." >> ~/wrapper.log

    # run the standard config and start script.
    exec "$script_dir/config-and-start.sh"
fi
