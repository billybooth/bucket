#!/bin/bash
#
# Copyright (c) 2021, Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl.
#

SCRIPT_DIR=$(cd $(dirname $0); pwd)

# Add both variants of the microsoft ODBC tools path to the path
export PATH="${PATH:+${PATH}:}/opt/mssql-tools/bin"
export PATH="${PATH:+${PATH}:}/opt/mssql-tools18/bin"

# Sleep for 30 seconds to give the database a chance to start up
sleep 30

# Wait 60 seconds for SQL Server to start up by ensuring that 
# calling SQLCMD does not return an error code, which will ensure that sqlcmd is accessible
# and that system and user databases return "0" which means all databases are in an "online" state
# https://docs.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-databases-transact-sql?view=sql-server-2017 

DBSTATUS=1
ERRCODE=1
i=0

while [ $DBSTATUS -ne 0 -a $i -lt 30 ]; do
   echo "********** Waiting for the database to start"
   i=$(expr $i + 1)
   DBSTATUS=$(sqlcmd -C -h -1 -t 1 -U sa -P $SA_PASSWORD -Q "SET NOCOUNT ON; Select SUM(state) from sys.databases")
   sleep 1
   DBSTATUS=${DBSTATUS:-1}
done

if [ $DBSTATUS -ne 0 ]; then 
   echo "********** SQL Server took more than 60 seconds to start up or one or more databases are not in an ONLINE state"
   exit 1
fi

# create the certdb database
sqlcmd -C -S localhost -U sa -P ${SA_PASSWORD} -d master -i ${SCRIPT_DIR}/setup.sql &

# create the samplebasic database
sqlcmd -C -S localhost -U sa -P ${SA_PASSWORD} -d master -i ${SCRIPT_DIR}/create.samplebasic.database.sqlserver.sql &

# Unlock the built-in Essbase MCP server (Essbase 26+) once Essbase has initialized its registry.
# Wait for the registry checksum row, not just the table: the registry derives feature flags
# (ENCRYPTION_AT_REST, MEMBER_ON_THE_FLY, AI_*) from OCI=TRUE when it first populates, and only
# recomputes them when its bundled entries file changes. Inserting after that first pass keeps
# those features off; the MCP gate reads OCI lazily and never caches a miss, so no restart is needed.
# Opt-in per stack: set ENABLE_ESSBASE_MCP=TRUE on the database service.
if [ "${ENABLE_ESSBASE_MCP^^}" = "TRUE" ]; then
   (
      i=0
      while [ $i -lt 360 ]; do
         i=$(expr $i + 1)
         FOUND=$(sqlcmd -C -h -1 -t 5 -U sa -P $SA_PASSWORD -d CertDB -Q "SET NOCOUNT ON; SELECT COUNT(*) FROM ESS1_ESSBASE.ESSBASE_PROPERTIES WHERE TYPE = 2" 2>/dev/null | tr -d '[:space:]')
         if [ "${FOUND:-0}" = "1" ]; then
            echo "********** Essbase registry initialized; enabling the built-in Essbase MCP server"
            sqlcmd -C -S localhost -U sa -P ${SA_PASSWORD} -d CertDB -i ${SCRIPT_DIR}/enable-mcp.sql
            exit 0
         fi
         sleep 10
      done
      echo "********** Essbase schema not found after 60 minutes; built-in Essbase MCP server not enabled"
   ) &
fi
