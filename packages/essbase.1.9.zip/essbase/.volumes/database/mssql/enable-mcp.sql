-- Unlock the built-in Essbase MCP server (Essbase 26+).
-- McpServiceV1 only serves /essbase/rest/v1/ess-mcp when AboutUtil.isMPInstance() is true,
-- which reads the Essbase registry base property OCI == TRUE. Registry rows are base64:
-- OCI = T0NJ, TRUE = VFJVRQ==. Idempotent: safe to run on every database start.
SET NOCOUNT ON;
IF NOT EXISTS (SELECT 1 FROM ESS1_ESSBASE.ESSBASE_PROPERTIES WHERE NAME = N'T0NJ' AND TYPE = 0)
BEGIN
    INSERT INTO ESS1_ESSBASE.ESSBASE_PROPERTIES (APPLICATION_NAME, DATABASE_NAME, NAME, TYPE, VALUE, EXTENDED_VALUE)
    VALUES (N'ESS_REG:__NO_APP_NAME__', N'ESS_REG:__NO_DB_NAME__', N'T0NJ', 0, N'VFJVRQ==', NULL);
    PRINT 'Essbase registry: OCI=TRUE added (built-in MCP unlocked).';
END
ELSE
    PRINT 'Essbase registry: OCI=TRUE already present.';
GO
